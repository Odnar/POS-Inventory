﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Thesis_Project
{
    public partial class Login : Form
    {
        MySqlConnection MyConn = new MySqlConnection();

        public Login()
        {
            InitializeComponent();
            MyConn.ConnectionString = "server = localhost; user id = root; password = admin; DATABASE = POS_INVENTORY";
         
        }

        private void timer1_Tick_1(object sender, EventArgs e)
        {
            try
            {
                DateTime dateTime = DateTime.Now;
                this.lblHour.Text = dateTime.ToString("hh:mm tt");
                this.lblDate.Text = dateTime.ToString("dddd, dd MMMM yyyy");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void picClose_Click(object sender, EventArgs e)
        {
            if (DialogResult.Yes == MessageBox.Show("Are you sure you want to exit?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Warning))
            {
                this.Close();
            }

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            try
            {
                MyConn.Open();

                MySqlCommand MyCommand = new MySqlCommand();
                string sql = "Select * from EmployeeInfo where UserName = '" + Username_txt.Text + "' and UserPassword = '" + Password_txt.Text + "'";
                MyCommand.Connection = MyConn;
                MyCommand.CommandText = sql;

                MySqlDataReader MyReader = MyCommand.ExecuteReader();

                int count = 0;

                while (MyReader.Read())
                {
                    count++;
                }

                MyReader.Close();
                if (count == 1)
                {
                    MySqlCommand MyCommandUser = new MySqlCommand();
                    string sqlUser = "insert into POS_INVENTORY.ActivityLog(LogUserName, LogUserType,LogDate,LogTime,LogActivity) values('" + Username_txt.Text + "','" + txtUserType.Text + "', '" + lblDate.Text + "', '" + lblHour.Text + "','Logged In')";
                    MyCommandUser.Connection = MyConn;
                    MyCommandUser.CommandText = sqlUser;
                    MyCommandUser.ExecuteNonQuery();


                    Main FormMain = new Main(Username_txt.Text,txtUserType.Text);
                    FormMain.Show();
                    this.Hide();

                   if (txtUserType.Text == "Cashier")
                   {

                       Point_of_Sale Main2 = new Point_of_Sale(txtUserType.Text, Username_txt.Text);
                       Main2.Show();
                       this.Hide();
                       FormMain.Close();
                   }
                   if (txtUserType.Text == "Stock Holder")
                   {

                       Inventory_Report Main23 = new Inventory_Report(txtUserType.Text, Username_txt.Text);
                        Main23.Show();
                       this.Hide();
                       FormMain.Close();
                   }
                }

                else
                {
                    MessageBox.Show("The Username or Password is INCORRECT!", "Important Note", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }

                MyConn.Close();
                Username_txt.Text = "";
                Password_txt.Text = "";
                txtUserType.Text = "";
                Username_txt.Focus();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }


        }

        private void Username_txt_Click(object sender, EventArgs e)
        {
            Username_txt.Text = "";
        }

        private void Password_txt_Click(object sender, EventArgs e)
        {
            Password_txt.Text = "";
        }

        private void txtID_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void Username_txt_TextChanged(object sender, EventArgs e)
        {
            try
            {

                MySqlCommand MyCommand = new MySqlCommand();
                string sql = "select * from POS_INVENTORY.EmployeeInfo where UserName = '" + Username_txt.Text + "'";
                MyCommand.Connection = MyConn;
                MyCommand.CommandText = sql;

                MyConn.Open();

                MySqlDataReader MyReader = MyCommand.ExecuteReader();

                if (MyReader.Read())
                {

                    txtUserType.Text = MyReader["UserType"].ToString();


                }
                MyConn.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Login_Load(object sender, EventArgs e)
        {

        }

        private void txtUserType_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtIDNum_TextChanged_1(object sender, EventArgs e)
        {
            
        }

        private void button1_Enter(object sender, EventArgs e)
        {
            
        }

        private void Username_txt_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                button1_Click_1(this, new EventArgs());
            }
        }

        private void Password_txt_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                button1_Click_1(this, new EventArgs());
            }
        }

        private void Username_txt_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = e.KeyChar != (char)Keys.Back && !char.IsSeparator(e.KeyChar) && !char.IsLetter(e.KeyChar) && !char.IsDigit(e.KeyChar);
       
    }

        private void Password_txt_KeyPress(object sender, KeyPressEventArgs e)
        {
        e.Handled = e.KeyChar != (char)Keys.Back && !char.IsSeparator(e.KeyChar) && !char.IsLetter(e.KeyChar) && !char.IsDigit(e.KeyChar);
    
}
    }
}
