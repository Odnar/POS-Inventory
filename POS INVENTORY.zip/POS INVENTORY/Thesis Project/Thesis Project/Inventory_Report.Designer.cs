﻿namespace Thesis_Project
{
    partial class Inventory_Report
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Inventory_Report));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lblHour = new System.Windows.Forms.Label();
            this.lblDate = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.picClose = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtQuantity = new System.Windows.Forms.TextBox();
            this.lblQuantity = new System.Windows.Forms.Label();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnAdd = new System.Windows.Forms.Button();
            this.txtID = new System.Windows.Forms.TextBox();
            this.txtProductName = new System.Windows.Forms.TextBox();
            this.txtBarcode = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtStocksOut = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtPrice = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.lblStocksOut = new System.Windows.Forms.Label();
            this.lblStocksOnHand = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.DataGridInv = new System.Windows.Forms.DataGridView();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.lblTotalProducts = new System.Windows.Forms.Label();
            this.lblUserName = new System.Windows.Forms.Label();
            this.lblUserType = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.txtStocksIn = new System.Windows.Forms.TextBox();
            this.txtStockMin = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tab2 = new System.Windows.Forms.TabControl();
            this.InventoryMaintenance = new System.Windows.Forms.TabPage();
            this.button1 = new System.Windows.Forms.Button();
            this.txtID1 = new System.Windows.Forms.TextBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.cmbCategory = new System.Windows.Forms.ComboBox();
            this.cmbSupplier = new System.Windows.Forms.ComboBox();
            this.cmbBrand = new System.Windows.Forms.ComboBox();
            this.TransferStock = new System.Windows.Forms.TabPage();
            this.label5 = new System.Windows.Forms.Label();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.dataGridViewTransferOut = new System.Windows.Forms.DataGridView();
            this.txtInvID = new System.Windows.Forms.TextBox();
            this.txtminimunstock1 = new System.Windows.Forms.TextBox();
            this.txtstocksout1 = new System.Windows.Forms.TextBox();
            this.txtcategory1 = new System.Windows.Forms.TextBox();
            this.txtsupplier1 = new System.Windows.Forms.TextBox();
            this.txtPrice1 = new System.Windows.Forms.TextBox();
            this.txtQuantity1 = new System.Windows.Forms.TextBox();
            this.txtBrand1 = new System.Windows.Forms.TextBox();
            this.txtBarcode1 = new System.Windows.Forms.TextBox();
            this.dataGridViewTransferIn = new System.Windows.Forms.DataGridView();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.txtTransferOut = new System.Windows.Forms.TextBox();
            this.button9 = new System.Windows.Forms.Button();
            this.label24 = new System.Windows.Forms.Label();
            this.button11 = new System.Windows.Forms.Button();
            this.txtProdName1 = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.txtQuan1 = new System.Windows.Forms.TextBox();
            this.cmbBranch2 = new System.Windows.Forms.ComboBox();
            this.label27 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.txtTransferIn = new System.Windows.Forms.TextBox();
            this.button6 = new System.Windows.Forms.Button();
            this.label20 = new System.Windows.Forms.Label();
            this.button8 = new System.Windows.Forms.Button();
            this.txtProdName = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.txtQuan = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.cmbBranch1 = new System.Windows.Forms.ComboBox();
            this.label23 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picClose)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DataGridInv)).BeginInit();
            this.tab2.SuspendLayout();
            this.InventoryMaintenance.SuspendLayout();
            this.TransferStock.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewTransferOut)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewTransferIn)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.panel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel2.Controls.Add(this.lblHour);
            this.panel2.Controls.Add(this.lblDate);
            this.panel2.Controls.Add(this.pictureBox1);
            this.panel2.Controls.Add(this.picClose);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Location = new System.Drawing.Point(0, -5);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1368, 69);
            this.panel2.TabIndex = 53;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // lblHour
            // 
            this.lblHour.BackColor = System.Drawing.Color.Transparent;
            this.lblHour.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHour.Location = new System.Drawing.Point(1222, 20);
            this.lblHour.Name = "lblHour";
            this.lblHour.Size = new System.Drawing.Size(67, 31);
            this.lblHour.TabIndex = 151;
            this.lblHour.Text = "00:00:00 tt";
            // 
            // lblDate
            // 
            this.lblDate.BackColor = System.Drawing.Color.Transparent;
            this.lblDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDate.Location = new System.Drawing.Point(1030, 24);
            this.lblDate.Name = "lblDate";
            this.lblDate.Size = new System.Drawing.Size(182, 26);
            this.lblDate.TabIndex = 150;
            this.lblDate.Text = "dddd dd MMMM, yyyy";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(0, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(87, 66);
            this.pictureBox1.TabIndex = 5;
            this.pictureBox1.TabStop = false;
            // 
            // picClose
            // 
            this.picClose.BackColor = System.Drawing.Color.Transparent;
            this.picClose.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picClose.BackgroundImage")));
            this.picClose.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picClose.Cursor = System.Windows.Forms.Cursors.Hand;
            this.picClose.Location = new System.Drawing.Point(1338, 3);
            this.picClose.Name = "picClose";
            this.picClose.Size = new System.Drawing.Size(30, 25);
            this.picClose.TabIndex = 4;
            this.picClose.TabStop = false;
            this.picClose.Click += new System.EventHandler(this.picClose_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Viner Hand ITC", 27F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(79, 3);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(193, 58);
            this.label1.TabIndex = 3;
            this.label1.Text = "Inventory";
            // 
            // txtQuantity
            // 
            this.txtQuantity.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.txtQuantity.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtQuantity.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtQuantity.ForeColor = System.Drawing.Color.Black;
            this.txtQuantity.Location = new System.Drawing.Point(277, 100);
            this.txtQuantity.Margin = new System.Windows.Forms.Padding(2);
            this.txtQuantity.Multiline = true;
            this.txtQuantity.Name = "txtQuantity";
            this.txtQuantity.Size = new System.Drawing.Size(256, 23);
            this.txtQuantity.TabIndex = 3;
            this.txtQuantity.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtQuantity_KeyDown);
            this.txtQuantity.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox1_KeyPress);
            // 
            // lblQuantity
            // 
            this.lblQuantity.AutoSize = true;
            this.lblQuantity.BackColor = System.Drawing.Color.Transparent;
            this.lblQuantity.Font = new System.Drawing.Font("Segoe UI Semibold", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQuantity.ForeColor = System.Drawing.Color.Black;
            this.lblQuantity.Location = new System.Drawing.Point(275, 72);
            this.lblQuantity.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblQuantity.Name = "lblQuantity";
            this.lblQuantity.Size = new System.Drawing.Size(68, 20);
            this.lblQuantity.TabIndex = 106;
            this.lblQuantity.Text = "Quantity";
            // 
            // btnUpdate
            // 
            this.btnUpdate.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnUpdate.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnUpdate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnUpdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpdate.ForeColor = System.Drawing.Color.White;
            this.btnUpdate.Location = new System.Drawing.Point(1146, 39);
            this.btnUpdate.Margin = new System.Windows.Forms.Padding(2);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(78, 39);
            this.btnUpdate.TabIndex = 10;
            this.btnUpdate.Text = "UPDATE";
            this.btnUpdate.UseVisualStyleBackColor = false;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnDelete.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDelete.ForeColor = System.Drawing.Color.White;
            this.btnDelete.Location = new System.Drawing.Point(1063, 87);
            this.btnDelete.Margin = new System.Windows.Forms.Padding(2);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(79, 39);
            this.btnDelete.TabIndex = 9;
            this.btnDelete.Text = "DELETE";
            this.btnDelete.UseVisualStyleBackColor = false;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnAdd.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdd.ForeColor = System.Drawing.Color.White;
            this.btnAdd.Location = new System.Drawing.Point(1063, 39);
            this.btnAdd.Margin = new System.Windows.Forms.Padding(2);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(79, 38);
            this.btnAdd.TabIndex = 8;
            this.btnAdd.Text = "ADD";
            this.btnAdd.UseVisualStyleBackColor = false;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // txtID
            // 
            this.txtID.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtID.ForeColor = System.Drawing.Color.Black;
            this.txtID.Location = new System.Drawing.Point(0, 72);
            this.txtID.Margin = new System.Windows.Forms.Padding(2);
            this.txtID.Name = "txtID";
            this.txtID.ReadOnly = true;
            this.txtID.Size = new System.Drawing.Size(0, 23);
            this.txtID.TabIndex = 58;
            // 
            // txtProductName
            // 
            this.txtProductName.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.txtProductName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtProductName.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtProductName.ForeColor = System.Drawing.Color.Black;
            this.txtProductName.Location = new System.Drawing.Point(17, 100);
            this.txtProductName.Margin = new System.Windows.Forms.Padding(2);
            this.txtProductName.Name = "txtProductName";
            this.txtProductName.Size = new System.Drawing.Size(256, 23);
            this.txtProductName.TabIndex = 1;
            this.txtProductName.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtProductName_KeyDown);
            this.txtProductName.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtProductName_KeyPress);
            // 
            // txtBarcode
            // 
            this.txtBarcode.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.txtBarcode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBarcode.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBarcode.ForeColor = System.Drawing.Color.Black;
            this.txtBarcode.Location = new System.Drawing.Point(17, 47);
            this.txtBarcode.Margin = new System.Windows.Forms.Padding(2);
            this.txtBarcode.MaxLength = 13;
            this.txtBarcode.Multiline = true;
            this.txtBarcode.Name = "txtBarcode";
            this.txtBarcode.Size = new System.Drawing.Size(256, 23);
            this.txtBarcode.TabIndex = 0;
            this.txtBarcode.TextChanged += new System.EventHandler(this.txtBarcode_TextChanged);
            this.txtBarcode.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtBarcode_KeyDown);
            this.txtBarcode.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtBarcode_KeyPress);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Segoe UI Semibold", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(793, 25);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(72, 20);
            this.label4.TabIndex = 7;
            this.label4.Text = "Category";
            // 
            // txtStocksOut
            // 
            this.txtStocksOut.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.txtStocksOut.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtStocksOut.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtStocksOut.ForeColor = System.Drawing.Color.Black;
            this.txtStocksOut.Location = new System.Drawing.Point(1243, 139);
            this.txtStocksOut.Margin = new System.Windows.Forms.Padding(2);
            this.txtStocksOut.Name = "txtStocksOut";
            this.txtStocksOut.ReadOnly = true;
            this.txtStocksOut.Size = new System.Drawing.Size(0, 24);
            this.txtStocksOut.TabIndex = 59;
            this.txtStocksOut.Text = "0";
            this.txtStocksOut.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Segoe UI Semibold", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(13, 25);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(65, 20);
            this.label6.TabIndex = 11;
            this.label6.Text = "Barcode";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Segoe UI Semibold", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(13, 78);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(108, 20);
            this.label3.TabIndex = 3;
            this.label3.Text = "Product Name";
            // 
            // txtPrice
            // 
            this.txtPrice.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.txtPrice.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPrice.ForeColor = System.Drawing.Color.Black;
            this.txtPrice.Location = new System.Drawing.Point(537, 46);
            this.txtPrice.Margin = new System.Windows.Forms.Padding(2);
            this.txtPrice.Name = "txtPrice";
            this.txtPrice.Size = new System.Drawing.Size(256, 24);
            this.txtPrice.TabIndex = 4;
            this.txtPrice.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtPrice.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtPrice_KeyDown);
            this.txtPrice.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtPrice_KeyPress);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("Segoe UI Semibold", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Black;
            this.label8.Location = new System.Drawing.Point(533, 78);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(66, 20);
            this.label8.TabIndex = 46;
            this.label8.Text = "Supplier";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.Transparent;
            this.label12.Font = new System.Drawing.Font("Segoe UI Semibold", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.Black;
            this.label12.Location = new System.Drawing.Point(33, 71);
            this.label12.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(0, 20);
            this.label12.TabIndex = 82;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Segoe UI Semibold", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(272, 24);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(50, 20);
            this.label7.TabIndex = 5;
            this.label7.Text = "Brand";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.Font = new System.Drawing.Font("Segoe UI Semibold", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Black;
            this.label9.Location = new System.Drawing.Point(533, 24);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(101, 20);
            this.label9.TabIndex = 42;
            this.label9.Text = "Product Price";
            // 
            // lblStocksOut
            // 
            this.lblStocksOut.AutoSize = true;
            this.lblStocksOut.BackColor = System.Drawing.Color.Transparent;
            this.lblStocksOut.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStocksOut.ForeColor = System.Drawing.Color.Black;
            this.lblStocksOut.Location = new System.Drawing.Point(1134, 638);
            this.lblStocksOut.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblStocksOut.Name = "lblStocksOut";
            this.lblStocksOut.Size = new System.Drawing.Size(18, 20);
            this.lblStocksOut.TabIndex = 110;
            this.lblStocksOut.Text = "0";
            // 
            // lblStocksOnHand
            // 
            this.lblStocksOnHand.AutoSize = true;
            this.lblStocksOnHand.BackColor = System.Drawing.Color.Transparent;
            this.lblStocksOnHand.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStocksOnHand.ForeColor = System.Drawing.Color.Black;
            this.lblStocksOnHand.Location = new System.Drawing.Point(742, 638);
            this.lblStocksOnHand.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblStocksOnHand.Name = "lblStocksOnHand";
            this.lblStocksOnHand.Size = new System.Drawing.Size(18, 20);
            this.lblStocksOnHand.TabIndex = 109;
            this.lblStocksOnHand.Text = "0";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.Color.Transparent;
            this.label15.Font = new System.Drawing.Font("Segoe UI Semibold", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.Black;
            this.label15.Location = new System.Drawing.Point(1045, 638);
            this.label15.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(85, 20);
            this.label15.TabIndex = 108;
            this.label15.Text = "Stocks Out:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.Color.Transparent;
            this.label14.Font = new System.Drawing.Font("Segoe UI Semibold", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.Black;
            this.label14.Location = new System.Drawing.Point(617, 638);
            this.label14.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(121, 20);
            this.label14.TabIndex = 107;
            this.label14.Text = "Stocks On Hand:";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.BackColor = System.Drawing.Color.Transparent;
            this.label17.Font = new System.Drawing.Font("Segoe UI Semibold", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.Black;
            this.label17.Location = new System.Drawing.Point(240, 638);
            this.label17.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(159, 20);
            this.label17.TabIndex = 106;
            this.label17.Text = "Total No. Of Products:";
            // 
            // DataGridInv
            // 
            this.DataGridInv.AllowUserToAddRows = false;
            this.DataGridInv.AllowUserToDeleteRows = false;
            this.DataGridInv.AllowUserToResizeRows = false;
            this.DataGridInv.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DataGridInv.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.DataGridInv.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DataGridInv.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.DataGridInv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.InactiveBorder;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.DataGridInv.DefaultCellStyle = dataGridViewCellStyle2;
            this.DataGridInv.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.DataGridInv.GridColor = System.Drawing.SystemColors.Control;
            this.DataGridInv.Location = new System.Drawing.Point(13, 180);
            this.DataGridInv.Margin = new System.Windows.Forms.Padding(2);
            this.DataGridInv.Name = "DataGridInv";
            this.DataGridInv.ReadOnly = true;
            this.DataGridInv.RowHeadersVisible = false;
            this.DataGridInv.RowTemplate.Height = 24;
            this.DataGridInv.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.DataGridInv.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DataGridInv.Size = new System.Drawing.Size(1323, 435);
            this.DataGridInv.TabIndex = 99;
            this.DataGridInv.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DataGridInv_CellDoubleClick);
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // lblTotalProducts
            // 
            this.lblTotalProducts.AutoSize = true;
            this.lblTotalProducts.BackColor = System.Drawing.Color.Transparent;
            this.lblTotalProducts.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotalProducts.ForeColor = System.Drawing.Color.Black;
            this.lblTotalProducts.Location = new System.Drawing.Point(404, 638);
            this.lblTotalProducts.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblTotalProducts.Name = "lblTotalProducts";
            this.lblTotalProducts.Size = new System.Drawing.Size(18, 20);
            this.lblTotalProducts.TabIndex = 111;
            this.lblTotalProducts.Text = "0";
            // 
            // lblUserName
            // 
            this.lblUserName.AutoSize = true;
            this.lblUserName.Location = new System.Drawing.Point(13, 153);
            this.lblUserName.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblUserName.Name = "lblUserName";
            this.lblUserName.Size = new System.Drawing.Size(0, 13);
            this.lblUserName.TabIndex = 153;
            this.lblUserName.Visible = false;
            // 
            // lblUserType
            // 
            this.lblUserType.AutoSize = true;
            this.lblUserType.Location = new System.Drawing.Point(13, 139);
            this.lblUserType.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblUserType.Name = "lblUserType";
            this.lblUserType.Size = new System.Drawing.Size(0, 13);
            this.lblUserType.TabIndex = 152;
            this.lblUserType.Visible = false;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.button2.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(1146, 86);
            this.button2.Margin = new System.Windows.Forms.Padding(2);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(80, 40);
            this.button2.TabIndex = 11;
            this.button2.Text = "CLEAR";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // textBox2
            // 
            this.textBox2.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.textBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox2.ForeColor = System.Drawing.Color.Black;
            this.textBox2.Location = new System.Drawing.Point(1106, 139);
            this.textBox2.Margin = new System.Windows.Forms.Padding(2);
            this.textBox2.Name = "textBox2";
            this.textBox2.ReadOnly = true;
            this.textBox2.Size = new System.Drawing.Size(0, 24);
            this.textBox2.TabIndex = 179;
            this.textBox2.Text = "0";
            this.textBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtStocksIn
            // 
            this.txtStocksIn.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.txtStocksIn.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtStocksIn.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtStocksIn.ForeColor = System.Drawing.Color.Black;
            this.txtStocksIn.Location = new System.Drawing.Point(1026, 195);
            this.txtStocksIn.Margin = new System.Windows.Forms.Padding(2);
            this.txtStocksIn.Name = "txtStocksIn";
            this.txtStocksIn.ReadOnly = true;
            this.txtStocksIn.Size = new System.Drawing.Size(0, 28);
            this.txtStocksIn.TabIndex = 10;
            this.txtStocksIn.Text = "0";
            this.txtStocksIn.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtStockMin
            // 
            this.txtStockMin.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.txtStockMin.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtStockMin.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtStockMin.ForeColor = System.Drawing.Color.Black;
            this.txtStockMin.Location = new System.Drawing.Point(797, 102);
            this.txtStockMin.Margin = new System.Windows.Forms.Padding(2);
            this.txtStockMin.Name = "txtStockMin";
            this.txtStockMin.Size = new System.Drawing.Size(256, 24);
            this.txtStockMin.TabIndex = 7;
            this.txtStockMin.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtStockMin.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtStockMin_KeyDown);
            this.txtStockMin.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtStockMin_KeyPress);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Segoe UI Semibold", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(797, 80);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(120, 20);
            this.label2.TabIndex = 180;
            this.label2.Text = "Minimum Stock ";
            // 
            // tab2
            // 
            this.tab2.Controls.Add(this.InventoryMaintenance);
            this.tab2.Controls.Add(this.TransferStock);
            this.tab2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tab2.Location = new System.Drawing.Point(3, 70);
            this.tab2.Name = "tab2";
            this.tab2.SelectedIndex = 0;
            this.tab2.Size = new System.Drawing.Size(1360, 694);
            this.tab2.TabIndex = 182;
            this.tab2.Click += new System.EventHandler(this.tabControl1_Click);
            // 
            // InventoryMaintenance
            // 
            this.InventoryMaintenance.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.InventoryMaintenance.Controls.Add(this.button1);
            this.InventoryMaintenance.Controls.Add(this.txtID1);
            this.InventoryMaintenance.Controls.Add(this.comboBox1);
            this.InventoryMaintenance.Controls.Add(this.textBox4);
            this.InventoryMaintenance.Controls.Add(this.label11);
            this.InventoryMaintenance.Controls.Add(this.cmbCategory);
            this.InventoryMaintenance.Controls.Add(this.cmbSupplier);
            this.InventoryMaintenance.Controls.Add(this.cmbBrand);
            this.InventoryMaintenance.Controls.Add(this.textBox2);
            this.InventoryMaintenance.Controls.Add(this.button2);
            this.InventoryMaintenance.Controls.Add(this.lblStocksOut);
            this.InventoryMaintenance.Controls.Add(this.lblTotalProducts);
            this.InventoryMaintenance.Controls.Add(this.txtStockMin);
            this.InventoryMaintenance.Controls.Add(this.txtProductName);
            this.InventoryMaintenance.Controls.Add(this.lblStocksOnHand);
            this.InventoryMaintenance.Controls.Add(this.label2);
            this.InventoryMaintenance.Controls.Add(this.label15);
            this.InventoryMaintenance.Controls.Add(this.label14);
            this.InventoryMaintenance.Controls.Add(this.txtBarcode);
            this.InventoryMaintenance.Controls.Add(this.label17);
            this.InventoryMaintenance.Controls.Add(this.label9);
            this.InventoryMaintenance.Controls.Add(this.DataGridInv);
            this.InventoryMaintenance.Controls.Add(this.label7);
            this.InventoryMaintenance.Controls.Add(this.label4);
            this.InventoryMaintenance.Controls.Add(this.btnAdd);
            this.InventoryMaintenance.Controls.Add(this.txtStocksOut);
            this.InventoryMaintenance.Controls.Add(this.btnDelete);
            this.InventoryMaintenance.Controls.Add(this.txtQuantity);
            this.InventoryMaintenance.Controls.Add(this.label8);
            this.InventoryMaintenance.Controls.Add(this.btnUpdate);
            this.InventoryMaintenance.Controls.Add(this.label6);
            this.InventoryMaintenance.Controls.Add(this.lblQuantity);
            this.InventoryMaintenance.Controls.Add(this.label3);
            this.InventoryMaintenance.Controls.Add(this.txtStocksIn);
            this.InventoryMaintenance.Controls.Add(this.txtPrice);
            this.InventoryMaintenance.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.InventoryMaintenance.Location = new System.Drawing.Point(4, 25);
            this.InventoryMaintenance.Name = "InventoryMaintenance";
            this.InventoryMaintenance.Padding = new System.Windows.Forms.Padding(3);
            this.InventoryMaintenance.Size = new System.Drawing.Size(1352, 665);
            this.InventoryMaintenance.TabIndex = 0;
            this.InventoryMaintenance.Text = "Inventory Maintenance";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.button1.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(1228, 37);
            this.button1.Margin = new System.Windows.Forms.Padding(2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(108, 89);
            this.button1.TabIndex = 186;
            this.button1.Text = "Product Restock";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // txtID1
            // 
            this.txtID1.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.txtID1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtID1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtID1.ForeColor = System.Drawing.Color.Black;
            this.txtID1.Location = new System.Drawing.Point(65, 151);
            this.txtID1.Margin = new System.Windows.Forms.Padding(2);
            this.txtID1.MaxLength = 13;
            this.txtID1.Multiline = true;
            this.txtID1.Name = "txtID1";
            this.txtID1.Size = new System.Drawing.Size(0, 0);
            this.txtID1.TabIndex = 185;
            // 
            // comboBox1
            // 
            this.comboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox1.ForeColor = System.Drawing.Color.Black;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(840, 150);
            this.comboBox1.Margin = new System.Windows.Forms.Padding(2);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(240, 25);
            this.comboBox1.TabIndex = 184;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // textBox4
            // 
            this.textBox4.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.textBox4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox4.ForeColor = System.Drawing.Color.Black;
            this.textBox4.Location = new System.Drawing.Point(424, 152);
            this.textBox4.Margin = new System.Windows.Forms.Padding(2);
            this.textBox4.MaxLength = 13;
            this.textBox4.Multiline = true;
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(412, 23);
            this.textBox4.TabIndex = 182;
            this.textBox4.TextChanged += new System.EventHandler(this.textBox4_TextChanged_1);
            this.textBox4.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox4_KeyPress);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.Transparent;
            this.label11.Font = new System.Drawing.Font("Segoe UI Semibold", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Black;
            this.label11.Location = new System.Drawing.Point(365, 153);
            this.label11.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(55, 20);
            this.label11.TabIndex = 183;
            this.label11.Text = "Search";
            // 
            // cmbCategory
            // 
            this.cmbCategory.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbCategory.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbCategory.ForeColor = System.Drawing.Color.Black;
            this.cmbCategory.FormattingEnabled = true;
            this.cmbCategory.Location = new System.Drawing.Point(797, 47);
            this.cmbCategory.Margin = new System.Windows.Forms.Padding(2);
            this.cmbCategory.Name = "cmbCategory";
            this.cmbCategory.Size = new System.Drawing.Size(256, 25);
            this.cmbCategory.TabIndex = 6;
            this.cmbCategory.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbCategory_KeyDown);
            // 
            // cmbSupplier
            // 
            this.cmbSupplier.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSupplier.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbSupplier.ForeColor = System.Drawing.Color.Black;
            this.cmbSupplier.FormattingEnabled = true;
            this.cmbSupplier.Location = new System.Drawing.Point(537, 100);
            this.cmbSupplier.Margin = new System.Windows.Forms.Padding(2);
            this.cmbSupplier.Name = "cmbSupplier";
            this.cmbSupplier.Size = new System.Drawing.Size(256, 25);
            this.cmbSupplier.TabIndex = 5;
            this.cmbSupplier.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbSupplier_KeyDown);
            // 
            // cmbBrand
            // 
            this.cmbBrand.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbBrand.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbBrand.ForeColor = System.Drawing.Color.Black;
            this.cmbBrand.FormattingEnabled = true;
            this.cmbBrand.Location = new System.Drawing.Point(277, 47);
            this.cmbBrand.Margin = new System.Windows.Forms.Padding(2);
            this.cmbBrand.Name = "cmbBrand";
            this.cmbBrand.Size = new System.Drawing.Size(256, 25);
            this.cmbBrand.TabIndex = 2;
            this.cmbBrand.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbBrand_KeyDown);
            // 
            // TransferStock
            // 
            this.TransferStock.Controls.Add(this.label5);
            this.TransferStock.Controls.Add(this.textBox6);
            this.TransferStock.Controls.Add(this.textBox5);
            this.TransferStock.Controls.Add(this.label19);
            this.TransferStock.Controls.Add(this.dataGridViewTransferOut);
            this.TransferStock.Controls.Add(this.txtInvID);
            this.TransferStock.Controls.Add(this.txtminimunstock1);
            this.TransferStock.Controls.Add(this.txtstocksout1);
            this.TransferStock.Controls.Add(this.txtcategory1);
            this.TransferStock.Controls.Add(this.txtsupplier1);
            this.TransferStock.Controls.Add(this.txtPrice1);
            this.TransferStock.Controls.Add(this.txtQuantity1);
            this.TransferStock.Controls.Add(this.txtBrand1);
            this.TransferStock.Controls.Add(this.txtBarcode1);
            this.TransferStock.Controls.Add(this.dataGridViewTransferIn);
            this.TransferStock.Controls.Add(this.groupBox2);
            this.TransferStock.Controls.Add(this.groupBox1);
            this.TransferStock.Location = new System.Drawing.Point(4, 25);
            this.TransferStock.Name = "TransferStock";
            this.TransferStock.Size = new System.Drawing.Size(1352, 665);
            this.TransferStock.TabIndex = 2;
            this.TransferStock.Text = "Transfer Stock ";
            this.TransferStock.UseVisualStyleBackColor = true;
            this.TransferStock.Click += new System.EventHandler(this.TransferStock_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Segoe UI Semibold", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(752, 216);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(158, 20);
            this.label5.TabIndex = 189;
            this.label5.Text = "Search Product Name";
            // 
            // textBox6
            // 
            this.textBox6.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.textBox6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox6.ForeColor = System.Drawing.Color.Black;
            this.textBox6.Location = new System.Drawing.Point(914, 215);
            this.textBox6.Margin = new System.Windows.Forms.Padding(2);
            this.textBox6.MaxLength = 13;
            this.textBox6.Multiline = true;
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(352, 23);
            this.textBox6.TabIndex = 188;
            this.textBox6.TextChanged += new System.EventHandler(this.textBox6_TextChanged);
            this.textBox6.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox6_KeyPress);
            // 
            // textBox5
            // 
            this.textBox5.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.textBox5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox5.ForeColor = System.Drawing.Color.Black;
            this.textBox5.Location = new System.Drawing.Point(250, 215);
            this.textBox5.Margin = new System.Windows.Forms.Padding(2);
            this.textBox5.MaxLength = 13;
            this.textBox5.Multiline = true;
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(352, 23);
            this.textBox5.TabIndex = 185;
            this.textBox5.TextChanged += new System.EventHandler(this.textBox5_TextChanged);
            this.textBox5.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox5_KeyPress);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.BackColor = System.Drawing.Color.Transparent;
            this.label19.Font = new System.Drawing.Font("Segoe UI Semibold", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.Color.Black;
            this.label19.Location = new System.Drawing.Point(88, 215);
            this.label19.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(158, 20);
            this.label19.TabIndex = 186;
            this.label19.Text = "Search Product Name";
            // 
            // dataGridViewTransferOut
            // 
            this.dataGridViewTransferOut.AllowUserToAddRows = false;
            this.dataGridViewTransferOut.AllowUserToDeleteRows = false;
            this.dataGridViewTransferOut.AllowUserToResizeRows = false;
            this.dataGridViewTransferOut.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewTransferOut.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.dataGridViewTransferOut.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTransferOut.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridViewTransferOut.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.InactiveBorder;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTransferOut.DefaultCellStyle = dataGridViewCellStyle4;
            this.dataGridViewTransferOut.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dataGridViewTransferOut.GridColor = System.Drawing.SystemColors.Control;
            this.dataGridViewTransferOut.Location = new System.Drawing.Point(683, 243);
            this.dataGridViewTransferOut.Margin = new System.Windows.Forms.Padding(2);
            this.dataGridViewTransferOut.Name = "dataGridViewTransferOut";
            this.dataGridViewTransferOut.ReadOnly = true;
            this.dataGridViewTransferOut.RowHeadersVisible = false;
            this.dataGridViewTransferOut.RowTemplate.Height = 24;
            this.dataGridViewTransferOut.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dataGridViewTransferOut.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewTransferOut.Size = new System.Drawing.Size(647, 375);
            this.dataGridViewTransferOut.TabIndex = 110;
            this.dataGridViewTransferOut.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewTransferOut_CellContentClick);
            // 
            // txtInvID
            // 
            this.txtInvID.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.txtInvID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtInvID.Location = new System.Drawing.Point(250, 16);
            this.txtInvID.Name = "txtInvID";
            this.txtInvID.Size = new System.Drawing.Size(0, 22);
            this.txtInvID.TabIndex = 109;
            // 
            // txtminimunstock1
            // 
            this.txtminimunstock1.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.txtminimunstock1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtminimunstock1.Location = new System.Drawing.Point(250, 16);
            this.txtminimunstock1.Name = "txtminimunstock1";
            this.txtminimunstock1.Size = new System.Drawing.Size(0, 22);
            this.txtminimunstock1.TabIndex = 108;
            // 
            // txtstocksout1
            // 
            this.txtstocksout1.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.txtstocksout1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtstocksout1.Location = new System.Drawing.Point(250, 16);
            this.txtstocksout1.Name = "txtstocksout1";
            this.txtstocksout1.Size = new System.Drawing.Size(0, 22);
            this.txtstocksout1.TabIndex = 107;
            // 
            // txtcategory1
            // 
            this.txtcategory1.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.txtcategory1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtcategory1.Location = new System.Drawing.Point(250, 16);
            this.txtcategory1.Name = "txtcategory1";
            this.txtcategory1.Size = new System.Drawing.Size(0, 22);
            this.txtcategory1.TabIndex = 106;
            // 
            // txtsupplier1
            // 
            this.txtsupplier1.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.txtsupplier1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtsupplier1.Location = new System.Drawing.Point(250, 16);
            this.txtsupplier1.Name = "txtsupplier1";
            this.txtsupplier1.Size = new System.Drawing.Size(0, 22);
            this.txtsupplier1.TabIndex = 104;
            // 
            // txtPrice1
            // 
            this.txtPrice1.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.txtPrice1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtPrice1.Location = new System.Drawing.Point(250, 16);
            this.txtPrice1.Name = "txtPrice1";
            this.txtPrice1.Size = new System.Drawing.Size(0, 22);
            this.txtPrice1.TabIndex = 103;
            // 
            // txtQuantity1
            // 
            this.txtQuantity1.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.txtQuantity1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtQuantity1.Location = new System.Drawing.Point(250, 16);
            this.txtQuantity1.Name = "txtQuantity1";
            this.txtQuantity1.Size = new System.Drawing.Size(0, 22);
            this.txtQuantity1.TabIndex = 102;
            // 
            // txtBrand1
            // 
            this.txtBrand1.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.txtBrand1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBrand1.Location = new System.Drawing.Point(250, 16);
            this.txtBrand1.Name = "txtBrand1";
            this.txtBrand1.Size = new System.Drawing.Size(0, 22);
            this.txtBrand1.TabIndex = 101;
            // 
            // txtBarcode1
            // 
            this.txtBarcode1.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.txtBarcode1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBarcode1.Location = new System.Drawing.Point(250, 16);
            this.txtBarcode1.Name = "txtBarcode1";
            this.txtBarcode1.Size = new System.Drawing.Size(0, 22);
            this.txtBarcode1.TabIndex = 37;
            // 
            // dataGridViewTransferIn
            // 
            this.dataGridViewTransferIn.AllowUserToAddRows = false;
            this.dataGridViewTransferIn.AllowUserToDeleteRows = false;
            this.dataGridViewTransferIn.AllowUserToResizeRows = false;
            this.dataGridViewTransferIn.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewTransferIn.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.dataGridViewTransferIn.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTransferIn.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle5;
            this.dataGridViewTransferIn.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.InactiveBorder;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTransferIn.DefaultCellStyle = dataGridViewCellStyle6;
            this.dataGridViewTransferIn.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dataGridViewTransferIn.GridColor = System.Drawing.SystemColors.Control;
            this.dataGridViewTransferIn.Location = new System.Drawing.Point(30, 243);
            this.dataGridViewTransferIn.Margin = new System.Windows.Forms.Padding(2);
            this.dataGridViewTransferIn.Name = "dataGridViewTransferIn";
            this.dataGridViewTransferIn.ReadOnly = true;
            this.dataGridViewTransferIn.RowHeadersVisible = false;
            this.dataGridViewTransferIn.RowTemplate.Height = 24;
            this.dataGridViewTransferIn.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dataGridViewTransferIn.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewTransferIn.Size = new System.Drawing.Size(647, 375);
            this.dataGridViewTransferIn.TabIndex = 100;
            this.dataGridViewTransferIn.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewTransferIn_CellContentClick);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.textBox3);
            this.groupBox2.Controls.Add(this.label18);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.txtTransferOut);
            this.groupBox2.Controls.Add(this.button9);
            this.groupBox2.Controls.Add(this.label24);
            this.groupBox2.Controls.Add(this.button11);
            this.groupBox2.Controls.Add(this.txtProdName1);
            this.groupBox2.Controls.Add(this.label25);
            this.groupBox2.Controls.Add(this.txtQuan1);
            this.groupBox2.Controls.Add(this.cmbBranch2);
            this.groupBox2.Controls.Add(this.label27);
            this.groupBox2.ForeColor = System.Drawing.Color.Black;
            this.groupBox2.Location = new System.Drawing.Point(683, 16);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(647, 178);
            this.groupBox2.TabIndex = 38;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Transfer Stock Out";
            // 
            // textBox3
            // 
            this.textBox3.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.textBox3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox3.Location = new System.Drawing.Point(173, 21);
            this.textBox3.MaxLength = 13;
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(357, 22);
            this.textBox3.TabIndex = 1;
            this.textBox3.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
            this.textBox3.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox3_KeyDown);
            this.textBox3.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox3_KeyPress);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.Color.Black;
            this.label18.Location = new System.Drawing.Point(101, 23);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(60, 16);
            this.label18.TabIndex = 39;
            this.label18.Text = "Barcode";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(63, 87);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(98, 16);
            this.label10.TabIndex = 37;
            this.label10.Text = "Stock On Hand";
            // 
            // txtTransferOut
            // 
            this.txtTransferOut.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.txtTransferOut.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtTransferOut.Location = new System.Drawing.Point(173, 142);
            this.txtTransferOut.Name = "txtTransferOut";
            this.txtTransferOut.Size = new System.Drawing.Size(357, 22);
            this.txtTransferOut.TabIndex = 5;
            this.txtTransferOut.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtTransferOut_KeyDown);
            this.txtTransferOut.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtTransferOut_KeyPress);
            // 
            // button9
            // 
            this.button9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.button9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button9.ForeColor = System.Drawing.Color.White;
            this.button9.Location = new System.Drawing.Point(536, 97);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(90, 52);
            this.button9.TabIndex = 7;
            this.button9.Text = "Clear";
            this.button9.UseVisualStyleBackColor = false;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.ForeColor = System.Drawing.Color.Black;
            this.label24.Location = new System.Drawing.Point(29, 144);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(132, 16);
            this.label24.TabIndex = 36;
            this.label24.Text = "Transfer Out Quantity";
            // 
            // button11
            // 
            this.button11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.button11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button11.ForeColor = System.Drawing.Color.White;
            this.button11.Location = new System.Drawing.Point(536, 39);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(90, 52);
            this.button11.TabIndex = 6;
            this.button11.Text = "Transfer Out";
            this.button11.UseVisualStyleBackColor = false;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // txtProdName1
            // 
            this.txtProdName1.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.txtProdName1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtProdName1.Location = new System.Drawing.Point(173, 52);
            this.txtProdName1.Name = "txtProdName1";
            this.txtProdName1.Size = new System.Drawing.Size(357, 22);
            this.txtProdName1.TabIndex = 2;
            this.txtProdName1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtProdName1_KeyDown);
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.ForeColor = System.Drawing.Color.Black;
            this.label25.Location = new System.Drawing.Point(111, 115);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(50, 16);
            this.label25.TabIndex = 35;
            this.label25.Text = "Branch";
            // 
            // txtQuan1
            // 
            this.txtQuan1.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.txtQuan1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtQuan1.Location = new System.Drawing.Point(173, 84);
            this.txtQuan1.Name = "txtQuan1";
            this.txtQuan1.Size = new System.Drawing.Size(357, 22);
            this.txtQuan1.TabIndex = 3;
            this.txtQuan1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtQuan1_KeyDown);
            // 
            // cmbBranch2
            // 
            this.cmbBranch2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbBranch2.FormattingEnabled = true;
            this.cmbBranch2.Location = new System.Drawing.Point(173, 112);
            this.cmbBranch2.Name = "cmbBranch2";
            this.cmbBranch2.Size = new System.Drawing.Size(357, 24);
            this.cmbBranch2.TabIndex = 4;
            this.cmbBranch2.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbBranch2_KeyDown);
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.ForeColor = System.Drawing.Color.Black;
            this.label27.Location = new System.Drawing.Point(67, 54);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(94, 16);
            this.label27.TabIndex = 33;
            this.label27.Text = "Product Name";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.textBox1);
            this.groupBox1.Controls.Add(this.label16);
            this.groupBox1.Controls.Add(this.txtTransferIn);
            this.groupBox1.Controls.Add(this.button6);
            this.groupBox1.Controls.Add(this.label20);
            this.groupBox1.Controls.Add(this.button8);
            this.groupBox1.Controls.Add(this.txtProdName);
            this.groupBox1.Controls.Add(this.label21);
            this.groupBox1.Controls.Add(this.txtQuan);
            this.groupBox1.Controls.Add(this.label22);
            this.groupBox1.Controls.Add(this.cmbBranch1);
            this.groupBox1.Controls.Add(this.label23);
            this.groupBox1.Location = new System.Drawing.Point(30, 16);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(707, 178);
            this.groupBox1.TabIndex = 37;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Transfer Stock In";
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox1.Location = new System.Drawing.Point(168, 25);
            this.textBox1.MaxLength = 13;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(364, 22);
            this.textBox1.TabIndex = 1;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged_1);
            this.textBox1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox1_KeyDown);
            this.textBox1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox1_KeyPress_1);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(94, 27);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(60, 16);
            this.label16.TabIndex = 38;
            this.label16.Text = "Barcode";
            // 
            // txtTransferIn
            // 
            this.txtTransferIn.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.txtTransferIn.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtTransferIn.Location = new System.Drawing.Point(168, 144);
            this.txtTransferIn.Name = "txtTransferIn";
            this.txtTransferIn.Size = new System.Drawing.Size(364, 22);
            this.txtTransferIn.TabIndex = 5;
            this.txtTransferIn.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtTransferIn_KeyDown);
            this.txtTransferIn.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtTransferIn_KeyPress);
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.ForeColor = System.Drawing.Color.White;
            this.button6.Location = new System.Drawing.Point(538, 100);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(90, 47);
            this.button6.TabIndex = 7;
            this.button6.Text = "Clear";
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(32, 146);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(122, 16);
            this.label20.TabIndex = 36;
            this.label20.Text = "Transfer In Quantity";
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button8.ForeColor = System.Drawing.Color.White;
            this.button8.Location = new System.Drawing.Point(538, 42);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(90, 52);
            this.button8.TabIndex = 6;
            this.button8.Text = "Transfer In";
            this.button8.UseVisualStyleBackColor = false;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // txtProdName
            // 
            this.txtProdName.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.txtProdName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtProdName.Location = new System.Drawing.Point(168, 53);
            this.txtProdName.Name = "txtProdName";
            this.txtProdName.Size = new System.Drawing.Size(364, 22);
            this.txtProdName.TabIndex = 2;
            this.txtProdName.TextChanged += new System.EventHandler(this.txtProdName_TextChanged);
            this.txtProdName.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtProdName_KeyDown);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(106, 117);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(50, 16);
            this.label21.TabIndex = 35;
            this.label21.Text = "Branch";
            // 
            // txtQuan
            // 
            this.txtQuan.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.txtQuan.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtQuan.Location = new System.Drawing.Point(168, 86);
            this.txtQuan.Name = "txtQuan";
            this.txtQuan.ReadOnly = true;
            this.txtQuan.Size = new System.Drawing.Size(364, 22);
            this.txtQuan.TabIndex = 3;
            this.txtQuan.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtQuan_KeyDown);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(58, 89);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(98, 16);
            this.label22.TabIndex = 34;
            this.label22.Text = "Stock On Hand";
            // 
            // cmbBranch1
            // 
            this.cmbBranch1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbBranch1.FormattingEnabled = true;
            this.cmbBranch1.Location = new System.Drawing.Point(168, 114);
            this.cmbBranch1.Name = "cmbBranch1";
            this.cmbBranch1.Size = new System.Drawing.Size(364, 24);
            this.cmbBranch1.TabIndex = 4;
            this.cmbBranch1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cmbBranch1_KeyDown);
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(62, 55);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(94, 16);
            this.label23.TabIndex = 33;
            this.label23.Text = "Product Name";
            // 
            // tabPage3
            // 
            this.tabPage3.Location = new System.Drawing.Point(0, 0);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(200, 100);
            this.tabPage3.TabIndex = 0;
            this.tabPage3.Text = "Stock Out";
            // 
            // Inventory_Report
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.ClientSize = new System.Drawing.Size(1300, 776);
            this.Controls.Add(this.tab2);
            this.Controls.Add(this.lblUserName);
            this.Controls.Add(this.lblUserType);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.txtID);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Inventory_Report";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Categories";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Inventory_Report_Load);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picClose)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DataGridInv)).EndInit();
            this.tab2.ResumeLayout(false);
            this.InventoryMaintenance.ResumeLayout(false);
            this.InventoryMaintenance.PerformLayout();
            this.TransferStock.ResumeLayout(false);
            this.TransferStock.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewTransferOut)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewTransferIn)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox picClose;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.TextBox txtID;
        private System.Windows.Forms.TextBox txtProductName;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtStocksOut;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtPrice;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label lblStocksOut;
        private System.Windows.Forms.Label lblStocksOnHand;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.DataGridView DataGridInv;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox txtBarcode;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lblHour;
        private System.Windows.Forms.Label lblDate;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.TextBox txtQuantity;
        private System.Windows.Forms.Label lblQuantity;
        private System.Windows.Forms.Label lblTotalProducts;
        private System.Windows.Forms.Label lblUserName;
        private System.Windows.Forms.Label lblUserType;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox txtStocksIn;
        private System.Windows.Forms.TextBox txtStockMin;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TabControl tab2;
        private System.Windows.Forms.TabPage InventoryMaintenance;
        private System.Windows.Forms.TabPage TransferStock;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.TextBox txtTransferIn;
        private System.Windows.Forms.ComboBox cmbBranch1;
        private System.Windows.Forms.TextBox txtQuan;
        private System.Windows.Forms.TextBox txtProdName;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox txtTransferOut;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.TextBox txtProdName1;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox txtQuan1;
        private System.Windows.Forms.ComboBox cmbBranch2;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.DataGridView dataGridViewTransferIn;
        private System.Windows.Forms.TextBox txtminimunstock1;
        private System.Windows.Forms.TextBox txtstocksout1;
        private System.Windows.Forms.TextBox txtcategory1;
        private System.Windows.Forms.TextBox txtsupplier1;
        private System.Windows.Forms.TextBox txtPrice1;
        private System.Windows.Forms.TextBox txtQuantity1;
        private System.Windows.Forms.TextBox txtBrand1;
        private System.Windows.Forms.TextBox txtBarcode1;
        private System.Windows.Forms.TextBox txtInvID;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox cmbBrand;
        private System.Windows.Forms.ComboBox cmbCategory;
        private System.Windows.Forms.ComboBox cmbSupplier;
        private System.Windows.Forms.DataGridView dataGridViewTransferOut;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox txtID1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button button1;
    }
}