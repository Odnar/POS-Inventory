﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Thesis_Project
{
    public partial class Branches : Form
    {
        MySqlConnection MyConn = new MySqlConnection();
        DataSet ds = new DataSet();
        public Branches(string message1, string message2)
        {
            InitializeComponent();
            MyConn.ConnectionString = "server = localhost; user id = root; password = admin; DATABASE = POS_INVENTORY";
            Display_Branch();
            lblUserName.Text = message1;
            lblUserType.Text = message2;
        }

        void Display_Branch()
        {
            try
            {
                MyConn.Open();

                MySqlCommand MyCommand = new MySqlCommand();
                string sql = "select BranchID as 'Branch ID', Branch, BranchAddress as 'Branch Address',BranchManager as 'Branch Manager',BranchContactNo as 'Branch Contact'from POS_INVENTORY.BranchInfo";
                MyCommand.Connection = MyConn;
                MyCommand.CommandText = sql;
                MySqlDataAdapter da = new MySqlDataAdapter(MyCommand);
                DataTable dt = new DataTable();

                dt.Clear();

                da.Fill(dt);
                DataGridBranch.DataSource = dt;

                MyConn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void Branches_Load(object sender, EventArgs e)
        {
            btnUpdateCategory.Enabled = false;
            btnDeleteCategory.Enabled = false;
        }

        private void picClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            try
            {
                DateTime dateTime = DateTime.Now;
                this.lblHour.Text = dateTime.ToString("hh:mm tt");
                this.lblDate.Text = dateTime.ToString("dddd, dd MMMM yyyy");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void DataGridCat_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
           
        }

        private void btnAddCategory_Click(object sender, EventArgs e)
        {
            try
            {
                if (btnAddCategory.Text == "Add")
                {
                
                    btnUpdateCategory.Enabled = false;
                    btnDeleteCategory.Enabled = false;
                    btnClearBranch.Enabled = true;
                    txtBranchID.Enabled = true;
                    txtBranch.Enabled = true;
                    txtBranchAddress.Enabled = true;
                    txtBranchContact.Enabled = true;
                    txtBranchManager.Enabled = true;
                   

                }
                if (txtBranch.Text == string.Empty)
                {
                    MessageBox.Show("Please enter a value to Branch Name!");
                    return;
                }
                else if (txtBranchAddress.Text == string.Empty)
                {
                    MessageBox.Show("Please enter a value to Branch Address!");
                    return;
                }
                else if (txtBranchContact.Text == string.Empty)
                {
                    MessageBox.Show("Please enter a value to Branch Contact!");
                    return;
                }
                else if (txtBranchManager.Text == string.Empty)
                {
                    MessageBox.Show("Please enter a value to Branch Manager!");
                    return;
                }
                else
                {
                    MySqlCommand cmd = new MySqlCommand("select * from BranchInfo where Branch = '" + txtBranch.Text + "' and BranchAddress = '" + txtBranchAddress.Text + "' and BranchContactNo = '" + txtBranchContact.Text + "' and BranchManager = '" + txtBranchManager.Text + "'", MyConn);
                    MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                    da.Fill(ds);
                    int i = ds.Tables[0].Rows.Count;
                    if (i > 0)
                    {
                        MessageBox.Show("Data Repeated!", "Important Note", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        ds.Clear();
                    }
                    else
                    {
                        MyConn.Open();
                        MySqlCommand MyCommaand = new MySqlCommand();
                        string sqal = "insert into BranchInfo(Branch,BranchAddress,BranchManager,BranchContactNo) values('" + txtBranch.Text + "', '" + txtBranchAddress.Text + "','" + txtBranchManager.Text + "', '" + txtBranchContact.Text + "');";
                        MyCommaand.Connection = MyConn;
                        MyCommaand.CommandText = sqal;
                        MyCommaand.ExecuteNonQuery();

                        MessageBox.Show("Branch Information Successfully Added!", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);

                        MySqlCommand CommandActivity = new MySqlCommand();
                        string sqlActivity = "insert into POS_INVENTORY.activitylog (LogUserName,LogUserType,LogDate,LogTime,LogActivity) values('" + lblUserName.Text + "', '" + lblUserType.Text + "', '" + lblDate.Text + "', '" + lblHour.Text + "', 'Added A Branch!')";
                        CommandActivity.Connection = MyConn;
                        CommandActivity.CommandText = sqlActivity;

                        CommandActivity.ExecuteNonQuery();

                        MyConn.Close();

                        btnUpdateCategory.Enabled = false;
                        btnDeleteCategory.Enabled = false;
                        btnClearBranch.Enabled = true;
                        txtBranchID.Enabled = true;
                        txtBranch.Enabled = true;
                        txtBranchAddress.Enabled = true;
                        txtBranchContact.Enabled = true;
                        txtBranchManager.Enabled = true;

                        Display_Branch();

                        txtBranchID.Text = "";
                        txtBranch.Text = "";
                        txtBranchAddress.Text = "";
                        txtBranchManager.Text = "";
                        txtBranchContact.Text = "";
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void btnUpdateCategory_Click(object sender, EventArgs e)
        {
            try
            {

                 if (txtBranchID.Text == "" && txtBranch.Text == "" && txtBranchAddress.Text == "" && txtBranchContact.Text == "" && txtBranchManager.Text == "")
                {
                    MessageBox.Show("Please Select Branch Info!", "", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else { 
                    MySqlCommand cmd = new MySqlCommand("select * from BranchInfo where Branch = '" + txtBranch.Text + "' and BranchAddress = '" + txtBranchAddress.Text + "' and BranchContactNo = '" + txtBranchContact.Text + "' and BranchManager = '" + txtBranchManager.Text + "'", MyConn);
                    MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                    da.Fill(ds);
                    int i = ds.Tables[0].Rows.Count;
                    if (i > 0)
                    {
                        MessageBox.Show("Data Repeated!", "Important Note", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        ds.Clear();
                    }
                    else
                    {
                        MyConn.Open();

                        MySqlCommand MyCommand = new MySqlCommand();
                        string sql = "update POS_INVENTORY.BranchInfo set Branch='" + txtBranch.Text + "', BranchAddress='" + txtBranchAddress.Text + "' , BranchManager='" + txtBranchManager.Text + "', BranchContactNo='" + txtBranchContact.Text + "'   where BranchID=" + txtBranchID.Text + "";
                        MyCommand.Connection = MyConn;
                        MyCommand.CommandText = sql;

                        MyCommand.ExecuteNonQuery();


                        MessageBox.Show("Successfully Updated!", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);

                        MySqlCommand MyCommandUser = new MySqlCommand();
                        string sqlUser = "insert into POS_INVENTORY.ActivityLog(LogUserName, LogUserType,LogDate,LogTime,LogActivity) values('" + lblUserName.Text + "','" + lblUserType.Text + "', '" + lblDate.Text + "', '" + lblHour.Text + "','Updated A Branch')";
                        MyCommandUser.Connection = MyConn;
                        MyCommandUser.CommandText = sqlUser;

                        MyCommandUser.ExecuteNonQuery();

                        MyConn.Close();
                        btnAddCategory.Enabled = true;
                        btnUpdateCategory.Enabled = false;
                        btnDeleteCategory.Enabled = false;
                        btnClearBranch.Enabled = true;
                        txtBranchID.Enabled = true;
                        txtBranch.Enabled = true;
                        txtBranchAddress.Enabled = true;
                        txtBranchContact.Enabled = true;
                        txtBranchManager.Enabled = true;
                        Display_Branch();
                        txtBranchID.Text = "";
                        txtBranch.Text = "";
                        txtBranchAddress.Text = "";
                        txtBranchManager.Text = "";
                        txtBranchContact.Text = "";
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnDeleteCategory_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtBranchID.Text == "" && txtBranch.Text == "" && txtBranchAddress.Text == "" && txtBranchContact.Text == "" && txtBranchManager.Text == "")
                {
                    MessageBox.Show("Please Select Branch Info!", "", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }

                else if (DialogResult.Yes == MessageBox.Show("Are you sure you want to delete the record?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Warning))
                {

                    MyConn.Open();

                    MySqlCommand MyCommand = new MySqlCommand();
                    string sql = "Delete from POS_INVENTORY.BranchInfo where BranchID=" + txtBranchID.Text + "";
                    MyCommand.Connection = MyConn;
                    MyCommand.CommandText = sql;

                    MyCommand.ExecuteNonQuery();

                    MessageBox.Show("Successfully Deleted!", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);

                    MySqlCommand MyCommandUser = new MySqlCommand();
                    string sqlUser = "insert into POS_INVENTORY.ActivityLog(LogUserName, LogUserType,LogDate,LogTime,LogActivity) values('" + lblUserName.Text + "','" + lblUserType.Text + "', '" + lblDate.Text + "', '" + lblHour.Text + "','Deleted A Branch')";
                    MyCommandUser.Connection = MyConn;
                    MyCommandUser.CommandText = sqlUser;

                    MyCommandUser.ExecuteNonQuery();

                    MyConn.Close();
                    Display_Branch();
                    btnAddCategory.Enabled = true;
                    btnUpdateCategory.Enabled = false;
                    btnDeleteCategory.Enabled = false;
                    txtBranchID.Text = "";
                    txtBranch.Text = "";
                    txtBranchAddress.Text = "";
                    txtBranchManager.Text = "";
                    txtBranchContact.Text = "";

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void DataGridBranch_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        private void DataGridBranch_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (btnAddCategory.Text == "Add")
                {
                    btnAddCategory.Enabled = false;
                    btnUpdateCategory.Enabled = true;
                    btnDeleteCategory.Enabled = true;
                    btnClearBranch.Enabled = true;
                    txtBranchID.Enabled = true;
                    txtBranch.Enabled = true;
                    txtBranchAddress.Enabled = true;
                    txtBranchContact.Enabled = true;
                    txtBranchManager.Enabled = true;


                }

                if (e.RowIndex >= 0)
                {
                    DataGridViewRow row = DataGridBranch.Rows[e.RowIndex];

                    txtBranchID.Text = row.Cells["Branch ID"].Value.ToString();
                    txtBranch.Text = row.Cells["Branch"].Value.ToString();
                    txtBranchAddress.Text = row.Cells["Branch Address"].Value.ToString();
                    txtBranchManager.Text = row.Cells["Branch Manager"].Value.ToString();
                    txtBranchContact.Text = row.Cells["Branch Contact"].Value.ToString();

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void txtBranchContact_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void txtBranchContact_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) &&
             (e.KeyChar != '.'))
            {
                e.Handled = true;
            }
            e.Handled = e.KeyChar != (char)Keys.Back && !char.IsSeparator(e.KeyChar) && !char.IsDigit(e.KeyChar);
      

    }

        private void btnClearBranch_Click(object sender, EventArgs e)
        {
            if (btnAddCategory.Text == "Add")
            {
                btnAddCategory.Enabled = true;
                btnClearBranch.Enabled = true;
                txtBranchID.Enabled = true;
                txtBranch.Enabled = true;
                txtBranchAddress.Enabled = true;
                txtBranchContact.Enabled = true;
                txtBranchManager.Enabled = true;
                btnUpdateCategory.Enabled = false;
                btnDeleteCategory.Enabled = false;

            }

            txtBranchID.Text = "";
            txtBranch.Text = "";
            txtBranchAddress.Text = "";
            txtBranchManager.Text = "";
            txtBranchContact.Text = "";
        }

        private void txtBranch_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtBranch_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                btnAddCategory_Click(this, new EventArgs());
            }

        }

        private void txtBranchAddress_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                btnAddCategory_Click(this, new EventArgs());
            }
        }

        private void txtBranchManager_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                btnAddCategory_Click(this, new EventArgs());
            }
        }

        private void txtBranchContact_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                btnAddCategory_Click(this, new EventArgs());
            }
        }

        private void txtBranch_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = e.KeyChar != (char)Keys.Back && !char.IsSeparator(e.KeyChar) && !char.IsLetter(e.KeyChar) && !char.IsDigit(e.KeyChar);
        
        }

        private void txtBranchAddress_KeyPress(object sender, KeyPressEventArgs e)
        {
        
    
        }

        private void txtBranchManager_KeyPress(object sender, KeyPressEventArgs e)
        {
        e.Handled = e.KeyChar != (char)Keys.Back && !char.IsSeparator(e.KeyChar) && !char.IsLetter(e.KeyChar) && !char.IsDigit(e.KeyChar);

        }

        private void txtBranchContact_KeyUp(object sender, KeyEventArgs e)
        {
           
        }
    }
}
