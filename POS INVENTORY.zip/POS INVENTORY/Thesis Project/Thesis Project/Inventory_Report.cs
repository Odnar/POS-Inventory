﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Drawing.Imaging;
using MySql.Data.MySqlClient;

namespace Thesis_Project
{
    public partial class Inventory_Report : Form
    {
        MySqlConnection MyConn = new MySqlConnection();
        DataSet ds = new DataSet();
        public Inventory_Report(string message1, string message2)
        {
            InitializeComponent();
            MyConn.ConnectionString = "server = localhost; user id = root; password = admin; DATABASE = POS_INVENTORY";
            Display_Inventory();
            Display_Inventory1();
            Display_Inventory2();
          
            Display_Brand();
            AddProduct();
            LessProduct();
            AddStock();
  
            Display_total_Product();
            DisplayStockIn();
            DisplayStockOut();
        
            Display_Branch();
            DisplayStockOut();
            Display_Category();
            Display_Suppliers();
            txtBarcode.Focus();
            textBox1.Focus();
            textBox3.Focus();

            lblUserName.Text = message1;
            lblUserType.Text = message2;
            comboBox1.Items.Add("Product Name");
            comboBox1.Items.Add("Category");
            comboBox1.Items.Add("Brand");
            comboBox1.Items.Add("Supplier");
        

        }

        private DataTable dt_Products = new DataTable();
       

        void Display_Inventory()
        {
            try
            {
                MyConn.Open();

                MySqlCommand MyCommand = new MySqlCommand();
                string sql = "select InventoryID as 'Inventory ID', ProductName as 'Product Name', Barcode, Price, Brand,  Supplier, Category,  StocksOut as 'Stocks Out', StocksOnHand as 'Stocks On Hand', StockMin as 'Stock Minimum' from InventoryInfo";
                MyCommand.Connection = MyConn;
                MyCommand.CommandText = sql;


                MySqlDataAdapter da = new MySqlDataAdapter(MyCommand);

                dt_Products.Clear();

                da.Fill(dt_Products);
                DataGridInv.DataSource = dt_Products;

                MyConn.Close();
           }
            catch (Exception ex)
            {
               MessageBox.Show(ex.Message);
           }
        }



        private DataTable dt_Transfer1 = new DataTable();

        void Display_Inventory1()
        {
            try
           {
                MyConn.Open();

                MySqlCommand MyCommand = new MySqlCommand();
                string sql = "select RecieveID as 'Recived ID', ProductName as 'Product Name', Barcode, TransferRecieve as 'Recieved Amount', BranchSender as 'Sender' from RecieverInfo";
                MyCommand.Connection = MyConn;
                MyCommand.CommandText = sql;

                MySqlDataAdapter da = new MySqlDataAdapter(MyCommand);

                dt_Transfer1.Clear();

                da.Fill(dt_Transfer1);
                dataGridViewTransferIn.DataSource = dt_Transfer1;

                MyConn.Close();
           }
            catch (Exception ex)
            {
               MessageBox.Show(ex.Message);
            }
        }

        private DataTable dt_Transfer2 = new DataTable();

        void Display_Inventory2()
        {
            try
            {
                MyConn.Open();

                MySqlCommand MyCommand = new MySqlCommand();
                string sql = "select TransferID as 'Transfer ID', ProductName as 'Product Name', Barcode, TransferAmount as 'Transfer Amount', BranchReciever as 'Reciever' from TransferInfo";
                MyCommand.Connection = MyConn;
                MyCommand.CommandText = sql;

                MySqlDataAdapter daa = new MySqlDataAdapter(MyCommand);

                dt_Transfer2.Clear();

                daa.Fill(dt_Transfer2);
                dataGridViewTransferOut.DataSource = dt_Transfer2;

                MyConn.Close();
           }
            catch (Exception ex)
           {
               MessageBox.Show(ex.Message);
           }
        }

        private DataTable dt_Transfer4 = new DataTable();
        
                
        void Display_Inventory4()
        {
            MyConn.Open();

                MySqlCommand MyCommmmmmmmmmand = new MySqlCommand();
                string sqlaaaaaaaaa = "select InventoryID as 'Inventory ID', ProductName as 'Product Name', Barcode, Brand, StocksOnHand as 'Stocks On Hand', StockMin as 'Stocks Minimum' from InventoryInfo where StocksOnHand <= StockMin";
                MyCommmmmmmmmmand.Connection = MyConn;
                MyCommmmmmmmmmand.CommandText = sqlaaaaaaaaa;

                MySqlDataAdapter dddddddaaaaa = new MySqlDataAdapter(MyCommmmmmmmmmand);

                dt_Transfer4.Clear();

                dddddddaaaaa.Fill(dt_Transfer4);
                DataGridInv.DataSource = dt_Transfer4;

                MyConn.Close();
            }



    void Display_Suppliers()
        {

            try
            {
                MyConn.Open();

                MySqlCommand MyCommand = new MySqlCommand();
                string sql = "select Supplier from POS_INVENTORY.SupplierInfo";
                MyCommand.Connection = MyConn;
                MyCommand.CommandText = sql;

                MySqlDataReader My = MyCommand.ExecuteReader();

                cmbSupplier.SelectedItem = null;
                cmbSupplier.Items.Clear();



                while (My.Read())
                {
                    cmbSupplier.Items.Add(My["Supplier"].ToString());

                }

                MyConn.Close();
           }
            catch (Exception ex)
           {
                MessageBox.Show(ex.Message);
            }
        }

        void Display_Category()
        {
            try
           {
                MyConn.Open();

                MySqlCommand MyCommand = new MySqlCommand();
                string sql = "select Category from POS_INVENTORY.CategoryInfo";
                MyCommand.Connection = MyConn;
                MyCommand.CommandText = sql;

                MySqlDataReader MyR = MyCommand.ExecuteReader();

                cmbCategory.SelectedItem = null;
                cmbCategory.Items.Clear();

                while (MyR.Read())
                {
                    cmbCategory.Items.Add(MyR["Category"].ToString());

                }

                MyConn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        void Display_Branch()
        {
            try
            {
                MyConn.Open();

                MySqlCommand MyCommand = new MySqlCommand();
                string sql = "select Branch from POS_INVENTORY.BranchInfo";
                MyCommand.Connection = MyConn;
                MyCommand.CommandText = sql;

                MySqlDataReader MyRe = MyCommand.ExecuteReader();
                cmbBranch1.SelectedItem = null;
                cmbBranch1.Items.Clear();

                while (MyRe.Read())
                {
                    cmbBranch1.Items.Add(MyRe["Branch"].ToString());
                    cmbBranch2.Items.Add(MyRe["Branch"].ToString());
                }

                MyConn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        void Display_Brand()
        {
            try
            {
                MyConn.Open();

                MySqlCommand MyCommand = new MySqlCommand();
                string sql = "select Brand from POS_INVENTORY.BrandInfo";
                MyCommand.Connection = MyConn;
                MyCommand.CommandText = sql;

                MySqlDataReader MyRea = MyCommand.ExecuteReader();
                cmbBrand.SelectedItem = null;
                cmbBrand.Items.Clear();

                while (MyRea.Read())
                {
                    cmbBrand.Items.Add(MyRea["Brand"].ToString());

                }

                MyConn.Close();
            }
            catch (Exception ex)
           {
               MessageBox.Show(ex.Message);
           }
        }

        void Display_total_Product()
        {
            lblTotalProducts.Text = DataGridInv.Rows.Count.ToString();
        }

        void DisplayStockIn()
        {
           try
           {
                decimal sum = 0;
               for (int i = 0; i < DataGridInv.Rows.Count; ++i)
              {
                    sum += Convert.ToInt32(DataGridInv.Rows[i].Cells[9].Value);
              }
                lblStocksOnHand.Text = sum.ToString();

           }
           catch (Exception ex)
            {
               MessageBox.Show(ex.Message);
            }
        }
   
        void DisplayStockOut()
        {
            try
            {
                decimal sum = 0;
                for (int i = 0; i < DataGridInv.Rows.Count; ++i)
                {
                    sum += Convert.ToInt32(DataGridInv.Rows[i].Cells[7].Value);
                }
                lblStocksOut.Text = sum.ToString();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void LessProduct()
        {

            MyConn.Open();
            MySqlCommand MyCommand = new MySqlCommand();
            string lessProd = " Update InventoryInfo Set StocksOnHand = StocksOnHand - '" + txtTransferOut.Text + "' where InventoryID = '" + txtInvID.Text + "' ";
            MySqlCommand newbook2 = new MySqlCommand(lessProd, MyConn);
            newbook2.ExecuteNonQuery();

            MyConn.Close();
            Display_Inventory();
            Display_Inventory1();
        }

        private void AddProduct()
        {

            MyConn.Open();
            MySqlCommand MyCommand = new MySqlCommand();
            string AddProd = " Update InventoryInfo Set StocksOnHand = StocksOnHand + '" + txtTransferIn.Text + "' where InventoryID = '" + txtInvID.Text + "' ";
            MySqlCommand newbook2 = new MySqlCommand(AddProd, MyConn);
            newbook2.ExecuteNonQuery();

            MyConn.Close();
            Display_Inventory();
            Display_Inventory1();
            Display_Inventory2();
        }

        private void AddStock()
        {

            MyConn.Open();
            MySqlCommand MyCommand = new MySqlCommand();
            string AddStock = " Update InventoryInfo Set StocksOnHand = StocksOnHand + '" + txtQuantity.Text + "' where InventoryID = '" + txtID1.Text + "' ";
            MySqlCommand newbook2 = new MySqlCommand(AddStock, MyConn);
            newbook2.ExecuteNonQuery();
            MyConn.Close();
            Display_Inventory();
            Display_Inventory1();
            Display_Inventory2();

        }


        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Inventory_Report_Load(object sender, EventArgs e)
        {
            DisplayStockIn();
            display_total_Product();
            DisplayStockOut();
            AddStock();
       
            txtBarcode.Focus();
            textBox1.Focus();
            textBox3.Focus();
          
            btnUpdate.Enabled = false;
            btnDelete.Enabled = false;
          
            button8.Enabled = false;
            button11.Enabled = false;
           

        }
        void display_total_Product()
        {
            lblTotalProducts.Text = DataGridInv.Rows.Count.ToString();
        }

        private void picClose_Click(object sender, EventArgs e)
        {
            MyConn.Open();
            MySqlCommand MyCommandUser = new MySqlCommand();
            string sqlUser = "insert into POS_INVENTORY.ActivityLog(LogUserName, LogUserType,LogDate,LogTime,LogActivity) values('" + lblUserName.Text + "','" + lblUserType.Text + "', '" + lblDate.Text + "', '" + lblHour.Text + "','Logged Out')";
            MyCommandUser.Connection = MyConn;
            MyCommandUser.CommandText = sqlUser;

            MyCommandUser.ExecuteNonQuery();

            this.Close();
           
            MyConn.Close();

        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
           try
            {
                if (txtProductName.Text == string.Empty &&  txtBarcode.Text == string.Empty && txtQuantity.Text == string.Empty && cmbBrand.Text == string.Empty && cmbSupplier.Text == string.Empty && cmbCategory.Text == string.Empty)
                {
                    MessageBox.Show("Please Select Inventory Info!", "", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }

                else if (DialogResult.Yes == MessageBox.Show("Are you sure you want to delete the record?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Warning))
                {

                    MyConn.Open();

                    MySqlCommand MyCommand = new MySqlCommand();
                    string sql = "Delete from POS_INVENTORY.InventoryInfo where InventoryID=" + txtID1.Text + "";
                    MyCommand.Connection = MyConn;
                    MyCommand.CommandText = sql;

                    MyCommand.ExecuteNonQuery();

                    MessageBox.Show("Product Successfully Deleted!", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);

                    MySqlCommand MyCommandUser = new MySqlCommand();
                    string sqlUser = "insert into POS_INVENTORY.ActivityLog(LogUserName, LogUserType,LogDate,LogTime,LogActivity) values('" + lblUserName.Text + "','" + lblUserType.Text + "', '" + lblDate.Text + "', '" + lblHour.Text + "','Deleted A Product')";
                    MyCommandUser.Connection = MyConn;
                    MyCommandUser.CommandText = sqlUser;

                    MyCommandUser.ExecuteNonQuery();

                    MyConn.Close();

                    Display_Inventory();
                    txtBarcode.Focus();
                    Display_total_Product();
                 DisplayStockIn();
                    DisplayStockOut();
                    Display_Inventory1();
              
                    btnAdd.Enabled = true;
                    btnUpdate.Enabled = false;
                    btnDelete.Enabled = false;
                    txtID.Text = "";
                    txtProductName.Text = "";
                    txtPrice.Text = "0.00";
                    txtBarcode.Text = "";
                    txtQuantity.Text = "";
                    cmbBrand.SelectedItem = null;
                    txtStocksIn.Text = "0";
                    txtStocksOut.Text = "0";
                    textBox2.Text = "0";
                    cmbSupplier.SelectedItem = null;
                    cmbCategory.SelectedItem = null;
                    txtStockMin.Text = "";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


        private void cmbSupplier_Click(object sender, EventArgs e)
        {
            Display_Suppliers();
        }

        private void cmbCategory_Click(object sender, EventArgs e)
        {
            Display_Category();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            try
            {
                DateTime dateTime = DateTime.Now;
                this.lblHour.Text = dateTime.ToString("hh:mm tt");
                this.lblDate.Text = dateTime.ToString("dddd, dd MMMM yyyy");
            }
            catch (Exception ex)
{
                MessageBox.Show(ex.Message);
            }
        }

        private void DataGridInv_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (btnAdd.Text == "ADD")
                {
                    btnAdd.Enabled = false;
                    btnUpdate.Enabled = true;
                    btnDelete.Enabled = true;
                    button2.Enabled = true;

                }


                if (e.RowIndex >= 0)
                {
                    DataGridViewRow row = DataGridInv.Rows[e.RowIndex];


                    txtBarcode.Text = row.Cells["Barcode"].Value.ToString();


                }
              
           }
           catch (Exception ex)
           {
                MessageBox.Show(ex.Message);
           }

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {


           try
           {

                if (txtProductName.Text == string.Empty && txtPrice.Text == string.Empty && txtBarcode.Text == string.Empty && txtQuantity.Text == string.Empty && cmbBrand.Text == string.Empty && cmbSupplier.Text == string.Empty && cmbCategory.Text == string.Empty)
                {
                    MessageBox.Show("Please fill the required field!", "", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                  
                    return;
                }
             
                else
                {
                    MySqlCommand cmd = new MySqlCommand("select * from InventoryInfo where Barcode = '" + txtBarcode.Text + "' and ProductName = '" + txtProductName.Text + "'", MyConn);
                    MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                    da.Fill(ds);
                    int i = ds.Tables[0].Rows.Count;
                    if (i > 0)
                    {
                        MessageBox.Show("Data Repeated!", "Important Note", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        ds.Clear();
                    }
                    else
                    {

                        MyConn.Open();
                        MySqlCommand MyCommand = new MySqlCommand();
                        string sql = "insert into InventoryInfo(ProductName,Barcode,Price,Brand,Supplier,Category, StocksOut, StocksOnHand, StockMin ) values('" + txtProductName.Text + "', '" + txtBarcode.Text + "', '" + txtPrice.Text + "','" + cmbBrand.Text + "','" + cmbSupplier.Text + "', '" + cmbCategory.Text + "', '" + txtStocksOut.Text + "','" + txtQuantity.Text + "','" + txtStockMin.Text + "');";
                        MyCommand.Connection = MyConn;
                        MyCommand.CommandText = sql;
                        MyCommand.ExecuteNonQuery();

                        MessageBox.Show("Product Successfully Added!", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);

                        MySqlCommand MyCommandUser = new MySqlCommand();
                        string sqlUser = "insert into POS_INVENTORY.ActivityLog(LogUserName, LogUserType,LogDate,LogTime,LogActivity) values('" + lblUserName.Text + "','" + lblUserType.Text + "', '" + lblDate.Text + "', '" + lblHour.Text + "','Added A New Product')";
                        MyCommandUser.Connection = MyConn;
                        MyCommandUser.CommandText = sqlUser;

                        MyCommandUser.ExecuteNonQuery();



                        MyConn.Close();
                        Display_Inventory1();
                        Display_Inventory();
                       
                        Display_total_Product();
                        DisplayStockIn();
                        DisplayStockOut();
                        AddStock();
                        txtID.Text = "";
                        txtProductName.Text = "";
                        txtPrice.Text = "";
                        txtBarcode.Text = "";
                        txtQuantity.Text = "";
                        cmbBrand.SelectedItem = null;
                        txtStocksIn.Text = "";
                        txtStocksOut.Text = "";
                        textBox2.Text = "";
                        cmbSupplier.SelectedItem = null;
                        cmbCategory.SelectedItem = null;
                        txtStockMin.Text = "";
                        btnAdd.Enabled = true;
                        btnUpdate.Enabled = true;
                        btnDelete.Enabled = true;
                        button2.Enabled = true;
                        txtID.Enabled = true;
                        txtProductName.Enabled = true;
                        txtBarcode.Enabled = true;
                        cmbBrand.Enabled = true;
                        txtPrice.Enabled = true;
                        cmbSupplier.Enabled = true;
                        cmbCategory.Enabled = true;
                        txtStocksOut.Enabled = true;
                        textBox2.Enabled = true;
                        txtStockMin.Enabled = true;
                        txtBarcode.Focus();
                        btnAdd.Enabled = true;
                        btnUpdate.Enabled = true;
                        btnDelete.Enabled = true;
                        button2.Enabled = true;
                    }
                }
            }
            catch (Exception ex)
           {
               MessageBox.Show(ex.Message);
            }

        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {

           try
           {
                if (txtProductName.Text == string.Empty && txtBarcode.Text == string.Empty && txtQuantity.Text == string.Empty && cmbBrand.Text == string.Empty && cmbSupplier.Text == string.Empty && cmbCategory.Text == string.Empty)
                {
                    MessageBox.Show("Please Select Inventory Info!", "", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }

                else
                {

                MyConn.Open();
                MySqlCommand MyCommand = new MySqlCommand();
                string sql = "update POS_INVENTORY.InventoryInfo set ProductName='" + txtProductName.Text + "', Price='" + txtPrice.Text + "',  Brand='" + cmbBrand.Text + "', Supplier='" + cmbSupplier.Text + "', Category='" + cmbCategory.Text + "' , StocksOut='" + txtStocksOut.Text + "', StocksOnHand='" + textBox2.Text + "', StockMin='" + txtStockMin.Text + "' where InventoryID=" + txtID1.Text + "";
                MyCommand.Connection = MyConn;
                MyCommand.CommandText = sql;

                MyCommand.ExecuteNonQuery();

                MessageBox.Show("Successfully Updated!", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);

                MySqlCommand MyCommandUser = new MySqlCommand();
                string sqlUser = "insert into POS_INVENTORY.ActivityLog(LogUserName, LogUserType,LogDate,LogTime,LogActivity) values('" + lblUserName.Text + "','" + lblUserType.Text + "', '" + lblDate.Text + "', '" + lblHour.Text + "','Updated A Product Info')";
                MyCommandUser.Connection = MyConn;
                MyCommandUser.CommandText = sqlUser;

                MyCommandUser.ExecuteNonQuery();

                MyConn.Close();
                Display_Inventory1();
                Display_Inventory();
                Display_total_Product();
                AddStock();
                txtID.Text = "";
                txtProductName.Text = "";
                txtPrice.Text = "";
                txtBarcode.Text = "";
                txtQuantity.Text = "";
                cmbBrand.SelectedItem = null;
                txtStocksIn.Text = "";
                txtStocksOut.Text = "";
                textBox2.Text = "";
                cmbSupplier.SelectedItem = null;
                cmbCategory.SelectedItem = null;
                txtStockMin.Text = "";
                btnAdd.Enabled = true;
                btnUpdate.Enabled = true;
                btnDelete.Enabled = true;
                button2.Enabled = true;
                txtID.Enabled = true;
                txtProductName.Enabled = true;
                txtBarcode.Enabled = true;
                cmbBrand.Enabled = true;
                txtPrice.Enabled = true;
                cmbSupplier.Enabled = true;
                cmbCategory.Enabled = true;
                txtStocksOut.Enabled = true;
                textBox2.Enabled = true;
                txtStockMin.Enabled = true;


            }
             }
             catch (Exception ex)
                 {
                    MessageBox.Show(ex.Message);
             }

        }


private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) &&
        (e.KeyChar != '.'))
            {
                e.Handled = true;
            }
            e.Handled = e.KeyChar != (char)Keys.Back && !char.IsSeparator(e.KeyChar) &&  !char.IsDigit(e.KeyChar);
        }

        private void txtPrice_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) &&
        (e.KeyChar != '.'))
            {
                e.Handled = true;
            }

            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
            e.Handled = e.KeyChar != (char)Keys.Back && !char.IsSeparator(e.KeyChar) &&  !char.IsDigit(e.KeyChar);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            btnAdd.Enabled = true;
            btnUpdate.Enabled = false;
            btnDelete.Enabled = false;
            button2.Enabled = true;
            txtID.Enabled = true;
            txtProductName.Enabled = true;
            txtBarcode.Enabled = true;
            cmbBrand.Enabled = true;
            txtPrice.Enabled = true;
            cmbSupplier.Enabled = true;
            cmbCategory.Enabled = true;
            txtStocksOut.Enabled = true;
            textBox2.Enabled = true;
            txtStockMin.Enabled = true;
            txtID.Text = "";
            txtProductName.Text = "";
            txtPrice.Text = "";
            txtBarcode.Text = "";
            txtQuantity.Text = "";
            cmbBrand.SelectedItem = null;
            txtStocksIn.Text = "";
            txtStocksOut.Text = "";
            textBox2.Text = "";
            cmbSupplier.SelectedItem = null;
            cmbCategory.SelectedItem = null;
            txtStockMin.Text = "";
            txtBarcode.Focus();
            Display_Inventory();
            textBox4.Text = "";
            comboBox1.SelectedItem = null;
        }

        private void button8_Click(object sender, EventArgs e)
        {
         
            try
           {
                if (cmbBranch1.Text == string.Empty)
                {
                    MessageBox.Show("Please Select the Branch you want to transfer!", "", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else if (txtTransferIn.Text == string.Empty)
                {
                    MessageBox.Show("Please Select the how many products you want to transfer!", "", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else
                {
                    MyConn.Open();
                    MySqlCommand MyCommaand = new MySqlCommand();
                    string sqla = "insert into POS_INVENTORY.RecieverInfo(ProductName, Barcode, TransferRecieve, BranchSender) values('" + txtProdName.Text + "', '" + textBox1.Text + "', '" + txtTransferIn.Text + "','" + cmbBranch1.Text + "')";
                    MyCommaand.Connection = MyConn;
                    MyCommaand.CommandText = sqla;

                    MyCommaand.ExecuteNonQuery();

                    MySqlCommand MyCommand = new MySqlCommand();
                    string sql = "update POS_INVENTORY.InventoryInfo set InventoryID='" + txtInvID.Text + "', ProductName='" + txtProdName.Text + "', Price='" + txtPrice1.Text + "', Barcode='" + txtBarcode1.Text + "', Brand='" + txtBrand1.Text + "', Supplier='" + txtsupplier1.Text + "', Category='" + txtcategory1.Text + "' , StocksOut='" + txtstocksout1.Text + "', StocksOnHand='" + txtQuan.Text + "', StockMin='" + txtminimunstock1.Text + "' where InventoryID=" + txtInvID.Text + "";
                    MyCommand.Connection = MyConn;
                    MyCommand.CommandText = sql;

                    MyCommand.ExecuteNonQuery();

                    MySqlCommand MyCommandUser = new MySqlCommand();
                    string sqlUser = "insert into POS_INVENTORY.ActivityLog(LogUserName, LogUserType,LogDate,LogTime,LogActivity) values('" + lblUserName.Text + "','" + lblUserType.Text + "', '" + lblDate.Text + "', '" + lblHour.Text + "','Product Transferred In')";
                    MyCommandUser.Connection = MyConn;
                    MyCommandUser.CommandText = sqlUser;

                    MyCommandUser.ExecuteNonQuery();

                    MyConn.Close();
                    MessageBox.Show("Successfully Transferred In!", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);

                    Display_Inventory1();
                    Display_Inventory();
                  
                    AddProduct();
                    txtInvID.Text = "";
                    textBox1.Text = "";
                    txtProdName.Text = "";
                    txtQuan.Text = "";
                    cmbBranch1.SelectedItem = null;
                    txtTransferIn.Text = "";
                    textBox1.Focus();
                }
           }
          catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
           }
        }
    
        private void button11_Click(object sender, EventArgs e)
        {
            try
            {

                if (cmbBranch2.Text == string.Empty)
                {
                    MessageBox.Show("Please Select the Branch you want to send to!", "", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                if (txtTransferOut.Text == string.Empty)
                {
                    MessageBox.Show("Please Select the how many products you want to send!", "", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }

                else
                {

                    int x = Convert.ToInt32(txtTransferOut.Text);
                   int y = Convert.ToInt32(txtminimunstock1.Text);
                    if (x > y)
                    {
                        MessageBox.Show("Product stock limit reached!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }

                    MyConn.Open();

                    MySqlCommand MyCommaand = new MySqlCommand();
                    string sqla = "insert into POS_INVENTORY.TransferInfo(ProductName, Barcode, TransferAmount, BranchReciever) values('" + txtProdName1.Text + "', '" + textBox3.Text + "', '" + txtTransferOut.Text + "','" + cmbBranch2.Text + "')";
                    MyCommaand.Connection = MyConn;
                    MyCommaand.CommandText = sqla;

                    MyCommaand.ExecuteNonQuery();

                    MySqlCommand MyCommand = new MySqlCommand();
                    string sql = "update POS_INVENTORY.InventoryInfo set InventoryID='" + txtInvID.Text + "', ProductName='" + txtProdName1.Text + "', Price='" + txtPrice1.Text + "', Barcode='" + txtBarcode1.Text + "', Brand='" + txtBrand1.Text + "', Supplier='" + txtsupplier1.Text + "', Category='" + txtcategory1.Text + "' , StocksOut='" + txtstocksout1.Text + "', StocksOnHand='" + txtQuan1.Text + "', StockMin='" + txtminimunstock1.Text + "' where InventoryID=" + txtInvID.Text + "";
                    MyCommand.Connection = MyConn;
                    MyCommand.CommandText = sql;

                    MyCommand.ExecuteNonQuery();

                    MySqlCommand MyCommandUser = new MySqlCommand();
                    string sqlUser = "insert into POS_INVENTORY.ActivityLog(LogUserName, LogUserType,LogDate,LogTime,LogActivity) values('" + lblUserName.Text + "','" + lblUserType.Text + "', '" + lblDate.Text + "', '" + lblHour.Text + "','Product Transferred Out')";
                    MyCommandUser.Connection = MyConn;
                    MyCommandUser.CommandText = sqlUser;

                    MyCommandUser.ExecuteNonQuery();

                    MyConn.Close();
                    MessageBox.Show("Successfully Transferred Out!", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    Display_Inventory2();
                    Display_Inventory1();
                    Display_Inventory();
                  
                    LessProduct();
                    textBox3.Text = "";
                    txtProdName1.Text = "";
                    txtQuan1.Text = "";
                    cmbBranch2.SelectedItem = null;
                    txtTransferOut.Text = "";
                    textBox3.Focus();
                }
            }
            catch (Exception ex)
           {
                MessageBox.Show(ex.Message);
            }

        }

        private void txtStockMin_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) &&
             (e.KeyChar != '.'))
            {
                e.Handled = true;
            }
            e.Handled = e.KeyChar != (char)Keys.Back && !char.IsSeparator(e.KeyChar) && !char.IsDigit(e.KeyChar);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            txtInvID.Text = "";
            textBox1.Text = "";
            txtProdName.Text = "";
            txtQuan.Text = "";
            cmbBranch1.SelectedItem = null;
            txtTransferIn.Text = "";
            textBox1.Focus();
            button8.Enabled = false;
            textBox5.Text = "";
        }

        private void TransferStock_Click(object sender, EventArgs e)
        {
            textBox1.Focus();
            textBox3.Focus();
        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {
            try
           {
                button8.Enabled = true;

                DataView dva = new DataView(dt_Transfer1);
                dva.RowFilter = string.Format("Barcode LIKE '%{0}%'", textBox1.Text);
                dataGridViewTransferIn.DataSource = dva;

                MySqlCommand MyCommand = new MySqlCommand();

                string mysql = "select * from POS_INVENTORY.InventoryInfo where Barcode = '" + textBox1.Text + "'";


                MyCommand.Connection = MyConn;

                MyCommand.CommandText = mysql;

                MyConn.Open();
                MySqlDataReader MyReaadeerr = MyCommand.ExecuteReader();


                while (MyReaadeerr.Read())
                {

                    string a = MyReaadeerr.GetString("InventoryID");
                    string b = MyReaadeerr.GetString("ProductName");
                    string c = MyReaadeerr.GetString("Barcode");
                    string eg = MyReaadeerr.GetString("Price");
                    string f = MyReaadeerr.GetString("Brand");
                    string g = MyReaadeerr.GetString("Supplier");
                    string h = MyReaadeerr.GetString("Category");
                    string i = MyReaadeerr.GetString("StocksOut");
                    string j = MyReaadeerr.GetString("StocksOnHand");
                    string k = MyReaadeerr.GetString("StockMin");

                    txtInvID.Text = a;
                    txtProdName.Text = b;
                    txtBarcode1.Text = c;
                    txtPrice1.Text = eg;
                    txtBrand1.Text = f;
                    txtsupplier1.Text = g;
                    txtcategory1.Text = h;
                    txtstocksout1.Text = i;
                    txtQuan.Text = j;
                    txtminimunstock1.Text = k;



                }
                MyConn.Close();

            }
           catch (Exception ex)
            {
               MessageBox.Show(ex.Message);

            }
}

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            try
         {
                button11.Enabled = true;

                DataView dvaa = new DataView(dt_Transfer2);
                dvaa.RowFilter = string.Format("Barcode LIKE '%{0}%'", textBox3.Text);
                dataGridViewTransferOut.DataSource = dvaa;

                MySqlCommand MyCommand = new MySqlCommand();

                string mysql = "select * from POS_INVENTORY.InventoryInfo where Barcode = '" + textBox3.Text + "'";

                MyCommand.Connection = MyConn;

                MyCommand.CommandText = mysql;
                MyConn.Open();
                MySqlDataReader MyReadeerr = MyCommand.ExecuteReader();

                while (MyReadeerr.Read())
                {

                    string a = MyReadeerr.GetString("InventoryID");
                    string b = MyReadeerr.GetString("ProductName");
                    string c = MyReadeerr.GetString("Barcode");
                    string eg = MyReadeerr.GetString("Price");
                    string f = MyReadeerr.GetString("Brand");
                    string g = MyReadeerr.GetString("Supplier");
                    string h = MyReadeerr.GetString("Category");
                    string i = MyReadeerr.GetString("StocksOut");
                    string j = MyReadeerr.GetString("StocksOnHand");
                    string k = MyReadeerr.GetString("StockMin");

                    txtInvID.Text = a;
                    txtProdName1.Text = b;
                    txtBarcode1.Text = c;
                    txtPrice1.Text = eg;
                    txtBrand1.Text = f;
                    txtsupplier1.Text = g;
                    txtcategory1.Text = h;
                    txtstocksout1.Text = i;
                    txtQuan1.Text = j;
                    txtminimunstock1.Text = k;

                }
                MyConn.Close();
            }
          catch (Exception ex)
           {
               MessageBox.Show(ex.Message);
           }

        }

        private void button9_Click(object sender, EventArgs e)
        {
            textBox3.Text = "";
            txtProdName1.Text = "";
            txtQuan1.Text = "";
            cmbBranch2.SelectedItem = null;
            txtTransferOut.Text = "";
            textBox3.Focus();
            button11.Enabled = false;
            textBox6.Text = "";
        }

        private void txtBarcode_TextChanged(object sender, EventArgs e)
        {
            try
            {
                btnAdd.Enabled = false;
                btnDelete.Enabled = true;
                btnUpdate.Enabled = true;
                DataView dv = new DataView(dt_Products);
                dv.RowFilter = string.Format("Barcode LIKE '%{0}%'", txtBarcode.Text);
                DataGridInv.DataSource = dv;


                MySqlCommand MyCommand = new MySqlCommand();

                string mysql = "select * from POS_INVENTORY.InventoryInfo where Barcode = '" + txtBarcode.Text + "'";

                MyCommand.Connection = MyConn;

                MyCommand.CommandText = mysql;
                MyConn.Open();
                MySqlDataReader MyReadeerr = MyCommand.ExecuteReader();

                while (MyReadeerr.Read())
                {

                    string a = MyReadeerr.GetString("InventoryID");
                    string b = MyReadeerr.GetString("ProductName");
                    string c = MyReadeerr.GetString("Barcode");
                    string eg = MyReadeerr.GetString("Price");
                    string f = MyReadeerr.GetString("Brand");
                    string g = MyReadeerr.GetString("Supplier");
                    string h = MyReadeerr.GetString("Category");
                    string i = MyReadeerr.GetString("StocksOut");
                    string j = MyReadeerr.GetString("StocksOnHand");
                    string k = MyReadeerr.GetString("StockMin");

                    txtID1.Text = a;
                    txtProductName.Text = b;
                    txtBarcode.Text = c;
                    txtPrice.Text = eg;
                    cmbBrand.Text = f;
                    cmbSupplier.Text = g;
                    cmbCategory.Text = h;
                    txtStocksOut.Text = i;
                    textBox2.Text = j;
                    txtStockMin.Text = k;

                }
                MyConn.Close();
           }
           catch (Exception ex)
            {
               MessageBox.Show(ex.Message);
            }

        }

        private void dataGridViewTransferIn_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
              


                if (e.RowIndex >= 0)
                {
                    DataGridViewRow row = dataGridViewTransferIn.Rows[e.RowIndex];


                    textBox1.Text = row.Cells["Barcode"].Value.ToString();


                }
            }
            catch (Exception ex)
            {
              MessageBox.Show(ex.Message);
            }
        }
 
        private void textBox4_TextChanged_1(object sender, EventArgs e)
        {
            try
            {
                if (comboBox1.Text == "Product Name")
                {
                    DataView dv = new DataView(dt_Products);
                    dv.RowFilter = string.Format("[Product Name] LIKE '%{0}%'", textBox4.Text);
                    DataGridInv.DataSource = dv;
                }
                else if (comboBox1.Text == "Brand")
                {
                    DataView dv = new DataView(dt_Products);
                    dv.RowFilter = string.Format("Brand LIKE '%{0}%'", textBox4.Text);
                    DataGridInv.DataSource = dv;
                }
                else if (comboBox1.Text == "Category")
                {
                    DataView dv = new DataView(dt_Products);
                    dv.RowFilter = string.Format("Category LIKE '%{0}%'", textBox4.Text);
                    DataGridInv.DataSource = dv;
                }
                else if (comboBox1.Text == "Supplier")
                {
                    DataView dv = new DataView(dt_Products);
                    dv.RowFilter = string.Format("Supplier LIKE '%{0}%'", textBox4.Text);
                    DataGridInv.DataSource = dv;
                }
               



            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {
            DataView dv = new DataView(dt_Transfer1);
            dv.RowFilter = string.Format("[Product Name] LIKE '%{0}%'", textBox5.Text);
            dataGridViewTransferIn.DataSource = dv;
        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {
            DataView dv = new DataView(dt_Transfer2);
            dv.RowFilter = string.Format("[Product Name] LIKE '%{0}%'", textBox6.Text);
            dataGridViewTransferOut.DataSource = dv;

        }

        private void RestockProduct_Click(object sender, EventArgs e)
        {
          
        }

        private void txtFName_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void dataGridView1_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        private void button5_Click(object sender, EventArgs e)
        {
           
        }


        private void btnClear_Click_1(object sender, EventArgs e)
        {
           
        }

        private void button1_Click(object sender, EventArgs e)
        {
           
        }

        private void txtTransferIn_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) &&
       (e.KeyChar != '.'))
            {
                e.Handled = true;
            }
            e.Handled = e.KeyChar != (char)Keys.Back && !char.IsSeparator(e.KeyChar) && !char.IsDigit(e.KeyChar);
        }

        private void txtTransferOut_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) &&
       (e.KeyChar != '.'))
            {
                e.Handled = true;
            }
            e.Handled = e.KeyChar != (char)Keys.Back && !char.IsSeparator(e.KeyChar) && !char.IsDigit(e.KeyChar);
        }

        private void textBox8_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) &&
       (e.KeyChar != '.'))
            {
                e.Handled = true;
            }
        }

        private void tabControl1_Click(object sender, EventArgs e)
        {
            bool InventoryMaintenanceClicked = true;
            bool TransferStockClicked = true;


            if (InventoryMaintenanceClicked == true)
            {
                txtBarcode.Focus();
            }
            if (TransferStockClicked == true)
            {
                textBox1.Focus();
               
            }
           
        }

        private void txtBarcode_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                 btnAdd_Click(this, new EventArgs());
              
            }
           

        }

        private void txtProductName_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
            
                    btnAdd_Click(this, new EventArgs());
             
            }
           
        }

        private void cmbBrand_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
               
                    btnAdd_Click(this, new EventArgs());
              
            }
           
        }

        private void txtQuantity_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
             
                    btnAdd_Click(this, new EventArgs());
                
            }
        }

        private void txtPrice_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
              
                    btnAdd_Click(this, new EventArgs());
                
            }
        }

        private void cmbSupplier_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                    btnAdd_Click(this, new EventArgs());
            
            }
        }

        private void cmbCategory_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
            
                    btnAdd_Click(this, new EventArgs());
             
            }
        }

        private void txtStockMin_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
          
                    btnAdd_Click(this, new EventArgs());
              
            }
        }

        private void textBox1_KeyDown(object sender, KeyEventArgs e)
        {
            button8.Enabled = true;
           
            if (e.KeyCode == Keys.Enter)
            {
             
                    btnAdd_Click(this, new EventArgs());
               
            }
        }

        private void txtProdName_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
             
                    btnAdd_Click(this, new EventArgs());
               
            }
        }

        private void txtQuan_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
           
                    btnAdd_Click(this, new EventArgs());
               
            }
        }

        private void cmbBranch1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
         
                    btnAdd_Click(this, new EventArgs());
               
            }
        }

        private void txtTransferIn_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
              
                    btnAdd_Click(this, new EventArgs());

            }
        }

        private void textBox3_KeyDown(object sender, KeyEventArgs e)
        {
            button11.Enabled = true;
            if (e.KeyCode == Keys.Enter)
            {
               
                    btnAdd_Click(this, new EventArgs());

            }
        }

        private void txtProdName1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                    btnAdd_Click(this, new EventArgs());
            }
        }

        private void txtQuan1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                    btnAdd_Click(this, new EventArgs());
            }
        }

        private void cmbBranch2_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
            
                    btnAdd_Click(this, new EventArgs());
            }
        }

        private void txtTransferOut_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
             
                    btnAdd_Click(this, new EventArgs());
           
            }
        }

        private void textBox8_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
               
                    btnAdd_Click(this, new EventArgs());
               
            }
        }
       
    private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
          
        }

        private void txtProdName_TextChanged(object sender, EventArgs e)
        {
           

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridViewTransferOut_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
         try
           {



                if (e.RowIndex >= 0)
                {
                    DataGridViewRow row = dataGridViewTransferOut.Rows[e.RowIndex];


                    textBox3.Text = row.Cells["Barcode"].Value.ToString();


                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            Display_Inventory4();
        }

        private void txtBarcode_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = e.KeyChar != (char)Keys.Back && !char.IsSeparator(e.KeyChar) && !char.IsLetter(e.KeyChar) && !char.IsDigit(e.KeyChar);
        }

        private void txtProductName_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = e.KeyChar != (char)Keys.Back && !char.IsSeparator(e.KeyChar) && !char.IsLetter(e.KeyChar) && !char.IsDigit(e.KeyChar);
        }

        private void textBox1_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            e.Handled = e.KeyChar != (char)Keys.Back && !char.IsSeparator(e.KeyChar) && !char.IsLetter(e.KeyChar) && !char.IsDigit(e.KeyChar);
        }

        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = e.KeyChar != (char)Keys.Back && !char.IsSeparator(e.KeyChar) && !char.IsLetter(e.KeyChar) && !char.IsDigit(e.KeyChar);
        }

        private void textBox4_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = e.KeyChar != (char)Keys.Back && !char.IsSeparator(e.KeyChar) && !char.IsLetter(e.KeyChar) && !char.IsDigit(e.KeyChar);
        }

        private void textBox5_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = e.KeyChar != (char)Keys.Back && !char.IsSeparator(e.KeyChar) && !char.IsLetter(e.KeyChar) && !char.IsDigit(e.KeyChar);
        }

        private void textBox6_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = e.KeyChar != (char)Keys.Back && !char.IsSeparator(e.KeyChar) && !char.IsLetter(e.KeyChar) && !char.IsDigit(e.KeyChar);
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }
    }
    }
 



