﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Thesis_Project
{
    public partial class Employee_Maintenance : Form
    {
        MySqlConnection MyConn = new MySqlConnection();
        DataSet ds = new DataSet();
        public Employee_Maintenance(string message1, string message2)
        {
            InitializeComponent();
            MyConn.ConnectionString = "server = localhost; user id = root; password = admin; DATABASE = POS_INVENTORY";
            Display_Employee();
            lblUserName.Text = message1;
            lblUserType.Text = message2;
            cmbUserType.Items.Add("Admin");
            cmbUserType.Items.Add("Stock Holder");
            cmbUserType.Items.Add("Cashier");
            cmbUserType.Items.Add("Manager");
            cmbUserType.Items.Add("Owner");

        }

        void Display_Employee()
        {
            try
            {
                MyConn.Open();

                MySqlCommand MyCommand = new MySqlCommand();
                string sql = "select EmployeeID, FName as 'First Name', MName as 'Middle Name', LName as 'Last Name', UserName as 'User Name', UserType as 'User Type',VoidPass as 'Void Password', UserPassword as 'Password' from POS_INVENTORY.EmployeeInfo";
                MyCommand.Connection = MyConn;
                MyCommand.CommandText = sql;

                MySqlDataAdapter da = new MySqlDataAdapter(MyCommand);
                DataTable dt = new DataTable();

                dt.Clear();

                da.Fill(dt);
                DataGridEmp.DataSource = dt;

                MyConn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void picClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            
            try
            {
                if( txtID.Text == "" && txtFName.Text == "" && txtMName.Text == "" && txtLName.Text == "" && txtUserName.Text == "" && cmbUserType.Text == "" && txtPassword.Text == "")
                {
                    MessageBox.Show("Please Select User Info!", "", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }

                 else if (DialogResult.Yes == MessageBox.Show("Are you sure you want to delete the record?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Warning))
                {

                    MyConn.Open();

                    MySqlCommand MyCommand = new MySqlCommand();
                    string sql = "Delete from POS_INVENTORY.EmployeeInfo where EmployeeID=" + txtID.Text + "";
                    MyCommand.Connection = MyConn;
                    MyCommand.CommandText = sql;

                    MyCommand.ExecuteNonQuery();

                    MessageBox.Show("User Successfully Deleted!", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);

                    MySqlCommand CommandActivity = new MySqlCommand();
                    string sqlActivity = "insert into POS_INVENTORY.activitylog (LogUserName,LogUserType,LogDate,LogTime,LogActivity) values('" + lblUserName.Text + "', '" + lblUserType.Text + "', '" + lblDate.Text + "', '" + lblHour.Text + "', 'Deleted A User Account')";
                    CommandActivity.Connection = MyConn;
                    CommandActivity.CommandText = sqlActivity;

                    CommandActivity.ExecuteNonQuery();

                    MyConn.Close();

                    Display_Employee();
                    btnAdd.Enabled = true;
                    btnUpdate.Enabled = false;
                    btnDelete.Enabled = false;
                    txtID.Text = "";
                    txtFName.Text = "";
                    txtMName.Text = "";
                    txtLName.Text = "";
                    txtUserName.Text = "";
                    cmbUserType.SelectedItem = null;
                    txtPassword.Text = "";
                    txtRePassword.Text = "";
               

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            if (btnAdd.Text == "Add")
            {
                btnAdd.Enabled = true;
                btnUpdate.Enabled = false;
                btnDelete.Enabled = false;
                btnClear.Enabled = true;
                txtID.Enabled = true;
                txtFName.Enabled = true;
                txtMName.Enabled = true;
                txtLName.Enabled = true;
                txtUserName.Enabled = true;
                cmbUserType.Enabled = true;
                txtPassword.Enabled = true;
                txtRePassword.Enabled = true;
            }
            txtID.Text = "";
            txtFName.Text = "";
            txtMName.Text = "";
            txtLName.Text = "";
            txtUserName.Text = "";
            cmbUserType.SelectedItem = null;
            txtPassword.Text = "";
            txtRePassword.Text = "";
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            

         try
            {
                if (btnAdd.Text == "Add")
                {

                    btnUpdate.Enabled = false;
                    btnDelete.Enabled = false;
                    btnClear.Enabled = true;
                    txtID.Enabled = true;
                    txtFName.Enabled = true;
                    txtMName.Enabled = true;
                    txtLName.Enabled = true;
                    txtUserName.Enabled = true;
                    cmbUserType.Enabled = true;
                    txtPassword.Enabled = true;
                    txtRePassword.Enabled = true;
                }

                if (txtPassword.Text != txtRePassword.Text)

                {
                    MessageBox.Show("The password is not same!", "", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    btnAdd.Text = "Add";

                }
                    if (txtFName.Text == string.Empty)
                    {
                        MessageBox.Show("Please enter a value to First Name!");
                        return;
                    }
                    else if (txtMName.Text == string.Empty)
                    {
                        MessageBox.Show("Please enter a value to Middle Name!");
                        return;
                    }
                    else if (txtLName.Text == string.Empty)
                    {
                        MessageBox.Show("Please enter a value to Last Name!");
                        return;
                    }
                    else if (txtUserName.Text == string.Empty)
                    {
                        MessageBox.Show("Please enter a value to User Name!");
                        return;
                    }
                    else if (cmbUserType.Text == string.Empty)
                    {
                        MessageBox.Show("Please enter a value to User Type!");
                        return;
                    }
                    else if (txtPassword.Text == string.Empty)
                    {
                        MessageBox.Show("Please enter a value to Password!");
                        return;
                    }
                    else if (txtRePassword.Text == string.Empty)
                    {
                        MessageBox.Show("Please enter a value to Retype Password!");
                        return;
                    }
                   else if(textBox1.Enabled == true && textBox1.Text == "")
                    {
                   
                        MessageBox.Show("Please enter a value to Void Password!");
                        return;
        
                    }
                    else
                    {
                        MySqlCommand cmd = new MySqlCommand("select * from EmployeeInfo where FName = '" + txtFName.Text + "' and MName = '" + txtMName.Text + "' and LName = '" + txtLName.Text + "' and UserType = '" + cmbUserType.Text + "' and VoidPass = '" + textBox1.Text + "'  and UserPassword = '" + txtPassword.Text + "'", MyConn);
                        MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                        da.Fill(ds);
                        int i = ds.Tables[0].Rows.Count;
                        if (i > 0)
                        {
                        MessageBox.Show("Data Repeated!", "Important Note", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        ds.Clear();
                        }
                        else
                        {

                            MyConn.Open();
                            MySqlCommand MyCommaand = new MySqlCommand();
                            string ssql = "insert into EmployeeInfo(FName,MName,LName,UserName,UserType,VoidPass,UserPassword) values('" + txtFName.Text + "', '" + txtLName.Text + "', '" + txtMName.Text + "','" + txtUserName.Text + "','" + cmbUserType.Text + "','" + textBox1.Text + "','" + txtPassword.Text + "');";
                            MyCommaand.Connection = MyConn;
                            MyCommaand.CommandText = ssql;
                            MyCommaand.ExecuteNonQuery();

                            MessageBox.Show("Employee Information Successfully Added!", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);

                            MySqlCommand CommandActivity = new MySqlCommand();
                            string sqlActivity = "insert into POS_INVENTORY.activitylog (LogUserName,LogUserType,LogDate,LogTime,LogActivity) values('" + lblUserName.Text + "', '" + lblUserType.Text + "', '" + lblDate.Text + "', '" + lblHour.Text + "', 'Added A User Account')";
                            CommandActivity.Connection = MyConn;
                            CommandActivity.CommandText = sqlActivity;

                            CommandActivity.ExecuteNonQuery();

                            MyConn.Close();
                            Display_Employee();

                            cmbUserType.Items.Add("");
                            btnUpdate.Enabled = true;
                            btnDelete.Enabled = true;
                            btnClear.Enabled = true;
                            txtID.Enabled = false;
                            txtFName.Enabled = true;
                            txtMName.Enabled = true;
                            txtLName.Enabled = true;
                            txtUserName.Enabled = true;
                            txtPassword.Enabled = true;
                            txtRePassword.Enabled = true;


                            txtID.Text = "";
                            txtFName.Text = "";
                            txtMName.Text = "";
                            txtLName.Text = "";
                            txtUserName.Text = "";
                            cmbUserType.SelectedItem = null;
                            txtPassword.Text = "";
                            txtRePassword.Text = "";
                        }
                    }
                
           }
            catch (Exception ex)
           {
              MessageBox.Show(ex.Message);
           }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {


             try
            {

             if (txtPassword.Text != txtRePassword.Text)
            {
                MessageBox.Show("The password is not the same!", "", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                btnUpdate.Text = "Update";
            }
            else
            {
                MySqlCommand cmd = new MySqlCommand("select * from EmployeeInfo where FName = '" + txtFName.Text + "' and MName = '" + txtMName.Text + "' and LName = '" + txtLName.Text + "' and UserName = '" + txtUserName.Text + "' and VoidPass = '" + textBox1.Text + "' and UserPassword = '" + txtPassword.Text + "'", MyConn);
                MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                da.Fill(ds);
                int i = ds.Tables[0].Rows.Count;
                    if (i > 0)
                    {
                        MessageBox.Show("Data Repeated!", "Important Note", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        ds.Clear();
                    }
                    else
                    {
                        MyConn.Open();
                        MySqlCommand MyCommaaaaaaaaaaaand = new MySqlCommand();
                        string sqlsqlsql = "update POS_INVENTORY.EmployeeInfo set FName = '" + txtFName.Text + "', MName = '" + txtMName.Text + "', LName = '" + txtLName.Text + "', UserName = '" + txtUserName.Text + "', VoidPass = '" + textBox1.Text + "', UserPassword = '" + txtPassword.Text + "' where EmployeeID =" + txtID.Text + "";
                        MyCommaaaaaaaaaaaand.Connection = MyConn;
                        MyCommaaaaaaaaaaaand.CommandText = sqlsqlsql;

                        MyCommaaaaaaaaaaaand.ExecuteNonQuery();

                        MessageBox.Show("Successfully Updated!", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);


                        MySqlCommand CommandActivity = new MySqlCommand();
                        string sqlActivity = "insert into POS_INVENTORY.activitylog (LogUserName,LogUserType,LogDate,LogTime,LogActivity) values('" + lblUserName.Text + "', '" + lblUserType.Text + "', '" + lblDate.Text + "', '" + lblHour.Text + "', 'Updated A User Account')";
                        CommandActivity.Connection = MyConn;
                        CommandActivity.CommandText = sqlActivity;

                        CommandActivity.ExecuteNonQuery();

                        MyConn.Close();

                        Display_Employee();
                        btnUpdate.Enabled = false;
                        btnAdd.Enabled = true;
                        btnDelete.Enabled = false;
                        btnClear.Enabled = true;
                        txtID.Text = "";
                        txtFName.Text = "";
                        txtMName.Text = "";
                        txtLName.Text = "";
                        txtUserName.Text = "";
                        cmbUserType.SelectedItem = null;
                        txtPassword.Text = "";
                        txtRePassword.Text = "";
                    }
                }
            }
            catch (Exception ex)
            {
               MessageBox.Show(ex.Message);
            }

        }

        private void DataGridEmp_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
           try
            {
                if (btnAdd.Text == "Add")
                {
                    btnAdd.Enabled = false;
                    btnUpdate.Enabled = true;
                    btnDelete.Enabled = true;
                    btnClear.Enabled = true;
                    txtID.Enabled = true;
                    txtFName.Enabled = true;
                    txtMName.Enabled = true;
                    txtLName.Enabled = true;
                    txtUserName.Enabled = true;
                    cmbUserType.Enabled = true;
                    txtPassword.Enabled = true;
                    txtRePassword.Enabled = true;
                }

                

                if (e.RowIndex >= 0)
                {
                    DataGridViewRow row = DataGridEmp.Rows[e.RowIndex];

                    txtID.Text = row.Cells["EmployeeID"].Value.ToString();
                    txtFName.Text = row.Cells["First Name"].Value.ToString();
                    txtMName.Text = row.Cells["Middle Name"].Value.ToString();
                    txtLName.Text = row.Cells["Last Name"].Value.ToString();
                    txtUserName.Text = row.Cells["User Name"].Value.ToString();
                    cmbUserType.Text = row.Cells["User Type"].Value.ToString();
                  
                    txtPassword.Text = row.Cells["Password"].Value.ToString();
                    txtRePassword.Text = row.Cells["Password"].Value.ToString();
                    textBox1.Text = row.Cells["Void Password"].Value.ToString();
            }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
           }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            try
            {
                DateTime dateTime = DateTime.Now;
                this.lblHour.Text = dateTime.ToString("hh:mm tt");
                this.lblDate.Text = dateTime.ToString("dddd, dd MMMM yyyy");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Employee_Maintenance_Load(object sender, EventArgs e)
        {
            textBox1.Enabled = false;
            btnUpdate.Enabled = false;
            btnDelete.Enabled = false;
        }

        private void txtFName_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                btnAdd_Click(this, new EventArgs());
            }
        }

        private void txtMName_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                btnAdd_Click(this, new EventArgs());
            }
        }

        private void txtLName_MouseDown(object sender, MouseEventArgs e)
        {
            
        }

        private void txtUserName_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                btnAdd_Click(this, new EventArgs());
            }
        }

        private void cmbUserType_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                btnAdd_Click(this, new EventArgs());
            }
        }

        private void txtLName_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                btnAdd_Click(this, new EventArgs());
            }
        }

        private void txtPassword_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                btnAdd_Click(this, new EventArgs());
            }
        }

        private void txtRePassword_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                btnAdd_Click(this, new EventArgs());
            }
        }

        private void cmbUserType_SelectedIndexChanged(object sender, EventArgs e)
        {
            textBox1.Text = "";
            if (cmbUserType.Text == "Manager")
            {
                textBox1.Enabled = true;
            }
            else if (cmbUserType.Text == "Admin")
            {
                textBox1.Enabled = true;
            }
            else if(cmbUserType.Text == "Owner")
            {
                textBox1.Enabled = true;
            }
            else
            {
                textBox1.Enabled = false;
            }
        }

        private void DataGridEmp_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void txtFName_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = e.KeyChar != (char)Keys.Back && !char.IsSeparator(e.KeyChar) && !char.IsLetter(e.KeyChar) && !char.IsDigit(e.KeyChar);
        }

        private void txtMName_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = e.KeyChar != (char)Keys.Back && !char.IsSeparator(e.KeyChar) && !char.IsLetter(e.KeyChar) && !char.IsDigit(e.KeyChar);
        }

        private void txtLName_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = e.KeyChar != (char)Keys.Back && !char.IsSeparator(e.KeyChar) && !char.IsLetter(e.KeyChar) && !char.IsDigit(e.KeyChar);
        }

        private void txtUserName_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = e.KeyChar != (char)Keys.Back && !char.IsSeparator(e.KeyChar) && !char.IsLetter(e.KeyChar) && !char.IsDigit(e.KeyChar);
        }

        private void cmbUserType_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = e.KeyChar != (char)Keys.Back && !char.IsSeparator(e.KeyChar) && !char.IsLetter(e.KeyChar) && !char.IsDigit(e.KeyChar);
        }

        private void txtPassword_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = e.KeyChar != (char)Keys.Back && !char.IsSeparator(e.KeyChar) && !char.IsLetter(e.KeyChar) && !char.IsDigit(e.KeyChar);
        }

        private void txtRePassword_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = e.KeyChar != (char)Keys.Back && !char.IsSeparator(e.KeyChar) && !char.IsLetter(e.KeyChar) && !char.IsDigit(e.KeyChar);
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = e.KeyChar != (char)Keys.Back && !char.IsSeparator(e.KeyChar) && !char.IsLetter(e.KeyChar) && !char.IsDigit(e.KeyChar);
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void textBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                btnAdd_Click(this, new EventArgs());
            }
        }
    }
    }

