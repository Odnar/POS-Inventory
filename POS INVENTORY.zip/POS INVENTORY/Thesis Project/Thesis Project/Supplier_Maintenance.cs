﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.Text.RegularExpressions;


namespace Thesis_Project
{
    public partial class Supplier_Maintenance : Form
    {
        MySqlConnection MyConn = new MySqlConnection();
        DataSet ds = new DataSet();
        public Supplier_Maintenance(string message1, string message2)
        {
            InitializeComponent();
            MyConn.ConnectionString = "server = localhost; user id = root; password = admin; DATABASE = POS_INVENTORY";
            Display_Supplier();
            lblUserName.Text = message1;
            lblUserType.Text = message2;

        }


        private DataTable dt_Supplier = new DataTable();

        void Display_Supplier()
        {
            try
            {

                MyConn.Open();

                MySqlCommand MyCommand = new MySqlCommand();
                string sql = "select SupplierID as 'Supplier ID', Supplier, Address,  Email, Information from SupplierInfo";
                MyCommand.Connection = MyConn;
                MyCommand.CommandText = sql;

                MySqlDataAdapter da = new MySqlDataAdapter(MyCommand);

                dt_Supplier.Clear();

                da.Fill(dt_Supplier);
                DataGridSup.DataSource = dt_Supplier;

                MyConn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void picClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            btnAdd.Enabled = true;
            btnUpdate.Enabled = false;
            btnDelete.Enabled = false;
            btnClear.Enabled = true;
            txtID.Enabled = true;
            txtSupplier.Enabled = true;
            txtAddress.Enabled = true;
            txtEmail.Enabled = true;
            txtInformation.Enabled = true;

            txtID.Text = "";
            txtSupplier.Text = "";
            txtAddress.Text = "";
            txtEmail.Text = "";
            txtInformation.Text = "";
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
           
            string email = txtEmail.Text;
            try
            {
                if (btnAdd.Text == "Add")
                {

                    btnUpdate.Enabled = false;
                    btnDelete.Enabled = false;
                    btnClear.Enabled = true;
                    txtID.Enabled = true;
                    txtSupplier.Enabled = true;
                    txtAddress.Enabled = true;
                    txtEmail.Enabled = true;
                    txtInformation.Enabled = true;

                }

                if (txtSupplier.Text == string.Empty)
                {
                    MessageBox.Show("Please enter a value to Supplier!");
                    return;
                }
                else if (txtAddress.Text == string.Empty)
                {
                    MessageBox.Show("Please enter a value to Address!");
                    return;
                }
                else if (txtEmail.Text == string.Empty)
                {
                    MessageBox.Show("Please enter a value to Email!");
                    return;
                }
                else if (txtInformation.Text == string.Empty)
                {
                    MessageBox.Show("Please enter a value to Information!");
                    return;
                }
                else
                {
                    MySqlCommand cmd = new MySqlCommand("select * from SupplierInfo where Supplier = '" + txtSupplier.Text + "' and Address = '" + txtAddress.Text + "' and Email = '" + txtEmail.Text + "' and Information = '" + txtInformation.Text + "'", MyConn);
                    MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                    da.Fill(ds);
                    int i = ds.Tables[0].Rows.Count;
                    if (i > 0)
                    {
                        MessageBox.Show("Data Repeated!", "Important Note", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        ds.Clear();
                    }

                    else if (email == txtEmail.Text)
                    {

                        System.Text.RegularExpressions.Regex expr = new System.Text.RegularExpressions.Regex(@"^[a-zA-Z][\w\.-]{2,28}[a-zA-Z0-9]@[a-zA-Z0-9][\w\.-]*[a-zA-Z0-9]\.[a-zA-Z][a-zA-Z\.]*[a-zA-Z]$");

                        if (expr.IsMatch(email))
                        {

                            MyConn.Open();

                            MySqlCommand MyCommand = new MySqlCommand();
                            string sql = "insert into SupplierInfo(Supplier,Address,Email,Information) values('" + txtSupplier.Text + "', '" + txtAddress.Text + "','" + txtEmail.Text + "','" + txtInformation.Text + "');";
                            MyCommand.Connection = MyConn;
                            MyCommand.CommandText = sql;
                            MyCommand.ExecuteNonQuery();

                            MessageBox.Show("Successfully Added!", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);

                            MySqlCommand MyCommandUser = new MySqlCommand();
                            string sqlUser = "insert into POS_INVENTORY.ActivityLog(LogUserName, LogUserType,LogDate,LogTime,LogActivity) values('" + lblUserName.Text + "','" + lblUserType.Text + "', '" + lblDate.Text + "', '" + lblHour.Text + "','Added A New Supplier')";
                            MyCommandUser.Connection = MyConn;
                            MyCommandUser.CommandText = sqlUser;

                            MyCommandUser.ExecuteNonQuery();

                            MyConn.Close();

                            btnUpdate.Enabled = false;
                            btnDelete.Enabled = false;
                            btnClear.Enabled = true;
                            txtID.Enabled = true;
                            txtSupplier.Enabled = true;
                            txtAddress.Enabled = true;
                            txtEmail.Enabled = true;
                            txtInformation.Enabled = true;


                            Display_Supplier();
                            txtID.Text = "";
                            txtSupplier.Text = "";
                            txtAddress.Text = "";
                            txtEmail.Text = "";
                            txtInformation.Text = "";
                        }

                        else MessageBox.Show("Invalid Email!", "", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            string email = txtEmail.Text;
            try
           {

                 if (email == txtEmail.Text)
                {
                    MySqlCommand cmd = new MySqlCommand("select * from SupplierInfo where Supplier = '" + txtSupplier.Text + "' and Address = '" + txtAddress.Text + "' and Email = '" + txtEmail.Text + "' and Information = '" + txtInformation.Text + "'", MyConn);
                    MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                    da.Fill(ds);
                    int i = ds.Tables[0].Rows.Count;
                    if (i > 0)
                    {
                        MessageBox.Show("Data Repeated!", "Important Note", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        ds.Clear();
                    }
                    else
                    {

                        MyConn.Open();

                        MySqlCommand MyCommaaaaaaaand = new MySqlCommand();
                        string sqlsql = "update SupplierInfo set Supplier='" + txtSupplier.Text + "', Address='" + txtAddress.Text + "', Email='" + txtEmail.Text + "',Information='" + txtInformation.Text + "' where SupplierID=" + txtID.Text + "";
                        MyCommaaaaaaaand.Connection = MyConn;
                        MyCommaaaaaaaand.CommandText = sqlsql;
                        MyCommaaaaaaaand.ExecuteNonQuery();

                        MessageBox.Show("Successfully Updated!", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);

                        MySqlCommand MyCommandUser = new MySqlCommand();
                        string sqlUser = "insert into POS_INVENTORY.ActivityLog(LogUserName, LogUserType,LogDate,LogTime,LogActivity) values('" + lblUserName.Text + "','" + lblUserType.Text + "', '" + lblDate.Text + "', '" + lblHour.Text + "','Updated A Supplier Info')";
                        MyCommandUser.Connection = MyConn;
                        MyCommandUser.CommandText = sqlUser;

                        MyCommandUser.ExecuteNonQuery();

                        MyConn.Close();
                        btnAdd.Enabled = true;
                        btnUpdate.Enabled = false;
                        btnDelete.Enabled = false;
                        btnClear.Enabled = true;
                        txtID.Enabled = true;
                        txtSupplier.Enabled = true;
                        txtAddress.Enabled = true;
                        txtEmail.Enabled = true;
                        txtInformation.Enabled = true;

                        Display_Supplier();
                        txtID.Text = "";
                        txtSupplier.Text = "";
                        txtAddress.Text = "";
                        txtEmail.Text = "";
                        txtInformation.Text = "";
                    }
                }
            }
         catch (Exception ex)
           {
              MessageBox.Show(ex.Message);
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtID.Text == "" && txtSupplier.Text == "" && txtAddress.Text == "" && txtEmail.Text == "" && txtInformation.Text == "")
                {
                    MessageBox.Show("Please Select Supplier Info!", "", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }

                else if (DialogResult.Yes == MessageBox.Show("Are you sure you want to delete the record?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Warning))
                {

                    MyConn.Open();

                    MySqlCommand MyCommand = new MySqlCommand();
                    string sql = "Delete from POS_INVENTORY.SupplierInfo where SupplierID=" + txtID.Text + "";
                    MyCommand.Connection = MyConn;
                    MyCommand.CommandText = sql;

                    MyCommand.ExecuteNonQuery();

                    MessageBox.Show("Supplier Successfully Deleted!", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);

                    MySqlCommand MyCommandUser = new MySqlCommand();
                    string sqlUser = "insert into POS_INVENTORY.ActivityLog(LogUserName, LogUserType,LogDate,LogTime,LogActivity) values('" + lblUserName.Text + "','" + lblUserType.Text + "', '" + lblDate.Text + "', '" + lblHour.Text + "','Deleted A Supplier')";
                    MyCommandUser.Connection = MyConn;
                    MyCommandUser.CommandText = sqlUser;

                    MyCommandUser.ExecuteNonQuery();

                    MyConn.Close();

                    Display_Supplier();
                    btnAdd.Enabled = true;
                    btnUpdate.Enabled = false;
                    btnDelete.Enabled = false;
                    txtID.Text = "";
                    txtSupplier.Text = "";
                    txtAddress.Text = "";
                    txtEmail.Text = "";
                    txtInformation.Text = "";

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
          
        }

        private void Supplier_Maintenance_Load(object sender, EventArgs e)
        {
            Display_Supplier();
            btnUpdate.Enabled = false;
            btnDelete.Enabled = false;

        }

        private void DataGridSup_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                {
                    if (btnAdd.Text == "Add")
                    {
                        btnAdd.Enabled = false;
                        btnUpdate.Enabled = true;
                        btnDelete.Enabled = true;
                        btnClear.Enabled = true;
                        txtID.Enabled = true;
                        txtSupplier.Enabled = true;
                        txtAddress.Enabled = true;
                        txtEmail.Enabled = true;
                        txtInformation.Enabled = true;

                    }


                    if (e.RowIndex >= 0)
                    {
                        DataGridViewRow row = DataGridSup.Rows[e.RowIndex];

                        txtID.Text = row.Cells["Supplier ID"].Value.ToString();
                        txtSupplier.Text = row.Cells["Supplier"].Value.ToString();
                        txtAddress.Text = row.Cells["Address"].Value.ToString();
                        txtEmail.Text = row.Cells["Email"].Value.ToString();
                        txtInformation.Text = row.Cells["Information"].Value.ToString();


                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            try
            {
                DateTime dateTime = DateTime.Now;
                this.lblHour.Text = dateTime.ToString("hh:mm tt");
                this.lblDate.Text = dateTime.ToString("dddd, dd MMMM yyyy");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void DataGridSup_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void DataGridSup_CellClick(object sender, DataGridViewCellEventArgs e)
        {
          
        }

        private void lblDate_Click(object sender, EventArgs e)
        {

        }

        private void txtEmail_TextChanged(object sender, EventArgs e)
        {
            

        }

        private void txtSupplier_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                btnAdd_Click(this, new EventArgs());
            }
        }

        private void txtAddress_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                btnAdd_Click(this, new EventArgs());
            }
           
        }

        private void txtEmail_KeyPress(object sender, KeyPressEventArgs e)
        {

        }

        private void txtEmail_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                btnAdd_Click(this, new EventArgs());
            }
        }

        private void txtInformation_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                btnAdd_Click(this, new EventArgs());
            }
        }

        private void txtSupplier_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = e.KeyChar != (char)Keys.Back && !char.IsSeparator(e.KeyChar) && !char.IsLetter(e.KeyChar) && !char.IsDigit(e.KeyChar);
        }

        private void txtInformation_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = e.KeyChar != (char)Keys.Back && !char.IsSeparator(e.KeyChar) && !char.IsLetter(e.KeyChar) && !char.IsDigit(e.KeyChar);
        }
    }
}
