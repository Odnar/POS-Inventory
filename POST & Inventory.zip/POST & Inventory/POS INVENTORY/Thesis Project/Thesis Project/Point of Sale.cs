﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.Drawing.Printing;

namespace Thesis_Project
{
    public partial class Point_of_Sale : Form
    {
        PrintDocument docPrint;
        MySqlConnection MyConn = new MySqlConnection();
        public Point_of_Sale(string message1, string message2)
        {
            InitializeComponent();
            MyConn.ConnectionString = "server = localhost; user id = root; password = admin; DATABASE = POS_INVENTORY";
            DisplayStockIn();
            Display_Activity();
            lblUserName.Text = message1;
            lblUserType.Text = message2;
            pictureBox4.Visible = true;
            textBox4.Visible = true;
            comboBox1.Visible = false;
            dataGridView1.Visible = false;
            label4.Visible = true;
            groupBox2.Visible = true;
            pictureBox2.Visible = false;
            label7.Visible = false;
            textBox2.Visible = false;
            button4.Visible = false;
            pictureBox5.Visible = false;
            label8.Visible = false;
            label9.Visible = false;
            comboBox1.Items.Add("Product Name");
            comboBox1.Items.Add("Brand");
            comboBox1.Items.Add("Category");
            AddStock();
            SubStock();
            MinusStock();
            ReturnStock();
            printPreviewDialog1 = new PrintPreviewDialog();
            docPrint = new PrintDocument();

            printPreviewDialog1.Document = docPrint;

        }

        private DataTable dt = new DataTable();

        void Display_Activity()
        {
            try
            {
                MyConn.Open();

                MySqlCommand MyCommand = new MySqlCommand();
                string sql = "select ProductName, Category, Brand,Price from POS_INVENTORY.InventoryInfo";
                MyCommand.Connection = MyConn;
                MyCommand.CommandText = sql;

                MySqlDataAdapter da = new MySqlDataAdapter(MyCommand);

                dt.Clear();

                da.Fill(dt);
                dataGridView1.DataSource = dt;

                MyConn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }



        void DisplayStockIn()
        {
            try
            {
                int sum = 0;
                for (int i = 0; i < DataGridViewPOS.Rows.Count; ++i)
                {
                    sum += Convert.ToInt32(DataGridViewPOS.Rows[i].Cells[1].Value);
                }
                txtPrice.Text = sum.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        DataTable table = new DataTable();

        private void AddStock()
        {

            MyConn.Open();
            MySqlCommand MyCommand = new MySqlCommand();
            string AddStock = " Update InventoryInfo Set StocksOnHand = StocksOnHand + '" + textBox1.Text + "' where ProductName = '" + txtProductName.Text + "' ";
            MySqlCommand newbook2 = new MySqlCommand(AddStock, MyConn);
            newbook2.ExecuteNonQuery();
            MyConn.Close();


        }

        private void MinusStock()
        {

            MyConn.Open();
            MySqlCommand MyCommand = new MySqlCommand();
            string AddStock = " Update InventoryInfo Set StocksOut = StocksOut + '" + textBox1.Text + "' where ProductName = '" + txtProductName.Text + "'";
            MySqlCommand newbook2 = new MySqlCommand(AddStock, MyConn);
            newbook2.ExecuteNonQuery();
            MyConn.Close();


        }


        private void ReturnStock()
        {

            MyConn.Open();
            MySqlCommand MyCommand = new MySqlCommand();
            string AddStock = " Update InventoryInfo Set StocksOut = StocksOut - '" + textBox1.Text + "' where ProductName = '" + txtProductName.Text + "' ";
            MySqlCommand newbook2 = new MySqlCommand(AddStock, MyConn);
            newbook2.ExecuteNonQuery();
            MyConn.Close();


        }


        private void SubStock()
        {

            MyConn.Open();
            MySqlCommand MyCommand = new MySqlCommand();
            string AddStock = " Update InventoryInfo Set StocksOnHand = StocksOnHand - '" + textBox1.Text + "'where ProductName = '" + txtProductName.Text + "'";
            MySqlCommand newbook2 = new MySqlCommand(AddStock, MyConn);
            newbook2.ExecuteNonQuery();
            MyConn.Close();


        }

        private void picClose_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            if (txtPrice.Text == "0")
            {
                MyConn.Open();
                MySqlCommand MyCommandUser = new MySqlCommand();
                string sqlUser = "insert into POS_INVENTORY.ActivityLog(LogUserName, LogUserType,LogDate,LogTime,LogActivity) values('" + lblUserName.Text + "','" + lblUserType.Text + "', '" + lblDate.Text + "', '" + lblHour.Text + "','Logged Out')";
                MyCommandUser.Connection = MyConn;
                MyCommandUser.CommandText = sqlUser;

                MyCommandUser.ExecuteNonQuery();

                this.Close();
               
                MyConn.Close();
            }

            else
            {
                MessageBox.Show("PLEASE CLEAR ALL TRANSACTION BEFORE LEAVING!", "Important Note", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            try
            {
                DateTime dateTime = DateTime.Now;
                this.lblHour.Text = dateTime.ToString("hh:mm tt");
                this.lblDate.Text = dateTime.ToString("dddd, dd MMMM yyyy");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void txtQuantity_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) &&
            (e.KeyChar != '.'))
            {
                e.Handled = true;
            }
        }


        private void textBox4_KeyPress(object sender, KeyPressEventArgs e)
        {
            var box = sender as TextBox;
            e.Handled = box.Text.Length == 13;
        }


        private void txtPayment_TextChanged_1(object sender, EventArgs e)
        {
            try
            {

                if (String.IsNullOrWhiteSpace(txtPayment.Text) || (txtPayment.Text == ""))
                {
                    txtChange.Text = "0";
                    txtInsufficient.Visible = false;

                }

                double Payment = Convert.ToDouble(txtPayment.Text);
                double Total = Convert.ToDouble(txtPrice.Text);

                double Change = Payment - Total;
                txtChange.Text = Convert.ToString(Change);

                if (Convert.ToDouble(txtPayment.Text) < (Convert.ToDouble(txtPrice.Text)))
                {
                    txtInsufficient.Visible = true;
                    txtChange.Visible = false;
                }
                else
                {
                    txtInsufficient.Visible = false;
                    txtChange.Visible = true;
                }

            }
            catch
            {
                txtPayment.Text = "";
            }
        }

        int indexRow;
        private void DataGridViewPOS_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            try
            {

                indexRow = e.RowIndex;

                DataGridViewRow row = DataGridViewPOS.Rows[indexRow];

                txtProductName.Text = row.Cells[0].Value.ToString();
                txtBrand.Text = row.Cells[1].Value.ToString();
                textBox1.Text = row.Cells[2].Value.ToString();
                txtProductPrice.Text = row.Cells[3].Value.ToString();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


        private void label4_Click(object sender, EventArgs e)
        {
            pictureBox2.Visible = true;
            pictureBox4.Visible = false;
            textBox4.Visible = true;
            comboBox1.Visible = true;
            dataGridView1.Visible = true;
            label4.Visible = false;
            groupBox2.Visible = false;
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            pictureBox2.Visible = false;
            pictureBox4.Visible = true;
            textBox4.Visible = false;
            comboBox1.Visible = false;
            dataGridView1.Visible = false;
            label4.Visible = true;
            groupBox2.Visible = true;
        }


        private void textBox3_KeyDown(object sender, KeyEventArgs e)
        {
            try
            {
                if (e.KeyCode == Keys.Enter)
                {
                    MyConn.Open();

                    MySqlCommand MyCommand = new MySqlCommand();
                    string sql = "Select * from InventoryInfo where Barcode = '" + textBox3.Text + "'";
                    MyCommand.Connection = MyConn;
                    MyCommand.CommandText = sql;

                    MySqlDataReader MyReader = MyCommand.ExecuteReader();
                    int count = 0;

                    while (MyReader.Read())
                    {
                        count++;
                        textBox3.SelectAll();

                    }

                    if (count == 1)
                    {
                        string a = MyReader.GetString("Brand");
                        string b = MyReader.GetString("ProductName");
                        string eg = MyReader.GetString("Price");

                        txtBrand.Text = a;
                        txtProductName.Text = b;
                        txtProductPrice.Text = eg;

                        decimal add = 0;

                        txtProductPrice.Text = Convert.ToString(((Convert.ToInt32(txtProductPrice.Text.Trim())) * (Convert.ToInt32(textBox1.Text.Trim()))));

                        int row = 0;

                        DataGridViewPOS.Rows.Add();
                        row = DataGridViewPOS.Rows.Count - 2;

                        DataGridViewPOS["Product", row].Value = txtProductName.Text;
                        DataGridViewPOS["Brand", row].Value = txtBrand.Text;
                        DataGridViewPOS["Quantity", row].Value = textBox1.Text;
                        DataGridViewPOS["Price", row].Value = txtProductPrice.Text;

                        for (int i = 0; i < DataGridViewPOS.Rows.Count; ++i)
                        {
                            add += Convert.ToDecimal(DataGridViewPOS.Rows[i].Cells[3].Value);
                        }
                        txtPrice.Text = add.ToString();

                    }
                    else
                    {
                        MessageBox.Show("The barcode INCORRECT!", "Important Note", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    }

                    MyConn.Close();
                    SubStock();
                    MinusStock();
                    txtProductName.Text = "";
                    txtBrand.Text = "";
                    textBox1.Text = "1";
                    txtProductPrice.Text = "";
                    textBox3.Text = "";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            try
            {

                if (comboBox1.Text == "Brand")
                {
                    DataView dv = new DataView(dt);
                    dv.RowFilter = string.Format("Brand LIKE '%{0}%'", textBox4.Text);
                    dataGridView1.DataSource = dv;
                }
                else if (comboBox1.Text == "Category")
                {
                    DataView dv = new DataView(dt);
                    dv.RowFilter = string.Format("Category LIKE '%{0}%'", textBox4.Text);
                    dataGridView1.DataSource = dv;
                }
                else if (comboBox1.Text == "Product Name")
                {
                    DataView dv = new DataView(dt);
                    dv.RowFilter = string.Format("ProductName LIKE '%{0}%'", textBox4.Text);
                    dataGridView1.DataSource = dv;
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


        private void pictureBox4_Click(object sender, EventArgs e)
        {
            pictureBox2.Visible = true;
            pictureBox4.Visible = false;
            textBox4.Visible = true;
            comboBox1.Visible = true;
            dataGridView1.Visible = true;
            label4.Visible = false;
            groupBox2.Visible = false;
        }

        private void button2_Click_2(object sender, EventArgs e)
        {

            try
            {
                decimal add = 0;
                decimal sub = 0;
                txtProductPrice.Text = Convert.ToString(((Convert.ToInt32(txtProductPrice.Text.Trim())) * (Convert.ToInt32(textBox1.Text.Trim()))));

                DataGridViewRow newDataRow = DataGridViewPOS.Rows[indexRow];

                newDataRow.Cells[0].Value = txtProductName.Text;
                newDataRow.Cells[1].Value = txtBrand.Text;
                newDataRow.Cells[2].Value = textBox1.Text;
                newDataRow.Cells[3].Value = txtProductPrice.Text;

                MessageBox.Show("Successfully Updated", "UPDATED");

                for (int i = 0; i < DataGridViewPOS.Rows.Count; ++i)
                {
                    add += Convert.ToDecimal(DataGridViewPOS.Rows[i].Cells[3].Value);

                }

                for (int i = 0; i > DataGridViewPOS.Rows.Count; --i)
                {
                    sub -= Convert.ToDecimal(DataGridViewPOS.Rows[i].Cells[3].Value);

                }

                txtPrice.Text = add.ToString();
                textBox3.Focus();
                txtProductName.Text = "";
                txtBrand.Text = "";
                textBox1.Text = "1";
                txtProductPrice.Text = "";
                textBox3.Text = "";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {


        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            txtProductName.Text = "";
            txtBrand.Text = "";
            textBox1.Text = "1";
            txtProductPrice.Text = "";
            textBox3.Text = "";
            textBox3.Focus();
        }

        private void textBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                textBox3.Focus();
            }
        }


        private void textBox2_KeyDown_1(object sender, KeyEventArgs e)
        {
            try { 
            if (e.KeyCode == Keys.Enter)
            {
                MyConn.Open();

                MySqlCommand MyCommand = new MySqlCommand();
                string sql = "Select * from EmployeeInfo where VoidPass = '" + textBox2.Text + "' ";
                MyCommand.Connection = MyConn;
                MyCommand.CommandText = sql;

                MySqlDataReader MyReader = MyCommand.ExecuteReader();

                int count = 0;

                while (MyReader.Read())
                {
                    count++;
                }

                MyReader.Close();
                if (count == 1)
                {
                    button4.Visible = true;
                    label8.Visible = true;
                    pictureBox5.Visible = true;
                    pictureBox4.Visible = false;
                    label4.Visible = false;
                    textBox2.Visible = false;
                    label7.Visible = false;
                }
                else {

                    MessageBox.Show("The password has no privilage!", "Important Note", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }

                MyConn.Close();

                textBox2.Text = "";
            
        }
    }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
}

        private void button4_Click(object sender, EventArgs e)
        {
            try { 
            decimal add = 0;

            if (txtBrand.Text == "" && txtProductName.Text == "" && txtPrice.Text == "" && textBox1.Text == "")
            {
                MessageBox.Show("Please Select Item to void!", "", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

        
            else if (DialogResult.Yes == MessageBox.Show("Are you sure you void the order?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Warning))
            {
                int rowIndex = DataGridViewPOS.CurrentCell.RowIndex;
                DataGridViewPOS.Rows.RemoveAt(rowIndex);
                AddStock();
                ReturnStock();
                txtProductName.Text = "";
                txtBrand.Text = "";
                textBox1.Text = "1";
                txtProductPrice.Text = "";
                textBox3.Text = "";
                textBox3.Focus();

                for (int i = 0; i < DataGridViewPOS.Rows.Count; ++i)
                {
                    add += Convert.ToDecimal(DataGridViewPOS.Rows[i].Cells[3].Value);
                }
                txtPrice.Text = add.ToString();
         
            }
        }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
}

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            pictureBox5.Visible = false;
            pictureBox4.Visible = true;
            label4.Visible = true;
            textBox2.Visible = false;
            label7.Visible = false;
            button4.Visible = false;
            label8.Visible = false;
            label9.Visible = false;

        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            Bitmap bma = Properties.Resources.Header;
            Image newImage = bma;
            e.Graphics.DrawImage(bma, 250, 25, newImage.Width, newImage.Height);

            Bitmap bm = new Bitmap(DataGridViewPOS.Width, DataGridViewPOS.Height);
            DataGridViewPOS.DrawToBitmap(bm, new Rectangle(150, 150, DataGridViewPOS.Width, DataGridViewPOS.Height));
            e.Graphics.DrawImage(bm, 0, 0);
        }
   
        private void txtPayment_KeyDown(object sender, KeyEventArgs e)
        {
            try {
                if (e.KeyCode == Keys.Enter)
                {
                    if (Convert.ToDouble(txtPayment.Text) < (Convert.ToDouble(txtPrice.Text)))
                    {
                        txtInsufficient.Visible = true;


                    }
                    else
                    {

                        MyConn.Open();
                        MySqlCommand MyCommaand = new MySqlCommand();
                        String sqal = "insert into SalesReport(ProductName,Brand,Dates,Times,Quantity,Amount) values('" + DataGridViewPOS.Rows[0].Cells[0].Value.ToString() + "','" + DataGridViewPOS.Rows[0].Cells[1].Value.ToString() + "','" + lblDate.Text + "','" + lblHour.Text + "','" + DataGridViewPOS.Rows[0].Cells[2].Value.ToString() + "','" + DataGridViewPOS.Rows[0].Cells[3].Value.ToString() + "')";
                        MyCommaand.Connection = MyConn;
                        MyCommaand.CommandText = sqal;


                        MyCommaand.ExecuteNonQuery();
                        MyConn.Close();

                        printPreviewDialog1.Document = printDocument1;
                        printPreviewDialog1.ShowDialog();
                        textBox3.Focus();
                        DataGridViewPOS.Rows.Clear();
                        DataGridViewPOS.Refresh();

                        textBox3.Text = "";
                        textBox1.Text = "1";
                        txtPayment.Text = "";
                        txtPrice.Text = "0";
                        txtChange.Text = "";

                    }


                }
         
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void Point_of_Sale_Load(object sender, EventArgs e)
        {
            button4.Enabled = false;
        }

        private void Point_of_Sale_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.F4 && e.Alt)
            {
                e.SuppressKeyPress = true;

            }

            if (e.KeyCode == Keys.ShiftKey)
            {
                textBox1.Focus();
               
                
            }
            if (e.KeyCode == Keys.Escape)
            {
                textBox3.Focus();


            }
            if (e.KeyCode == Keys.ControlKey)
            {

                txtPayment.Focus();


            }
            if (e.KeyCode == Keys.Home)
            {

                pictureBox5.Visible = true;
                pictureBox4.Visible = false;
                label4.Visible = false;
                textBox2.Visible = true;
                label7.Visible = true;
                label9.Visible = true;
                textBox2.Focus();

            }
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) &&
       (e.KeyChar != '.'))
            {
                e.Handled = true;
            }
            e.Handled = e.KeyChar != (char)Keys.Back && !char.IsSeparator(e.KeyChar) && !char.IsDigit(e.KeyChar);
        }

        private void txtPayment_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) &&
       (e.KeyChar != '.'))
            {
                e.Handled = true;
            }
            e.Handled = e.KeyChar != (char)Keys.Back && !char.IsSeparator(e.KeyChar) && !char.IsDigit(e.KeyChar);
        }

        private void printPreviewDialog1_Load(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = e.KeyChar != (char)Keys.Back && !char.IsSeparator(e.KeyChar) && !char.IsLetter(e.KeyChar) && !char.IsDigit(e.KeyChar);
        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = e.KeyChar != (char)Keys.Back && !char.IsSeparator(e.KeyChar) && !char.IsLetter(e.KeyChar) && !char.IsDigit(e.KeyChar);
        }

        private void textBox4_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            
        }

        private void textBox4_KeyPress_2(object sender, KeyPressEventArgs e)
        {
            e.Handled = e.KeyChar != (char)Keys.Back && !char.IsSeparator(e.KeyChar) && !char.IsLetter(e.KeyChar) && !char.IsDigit(e.KeyChar);
        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        private void DataGridViewPOS_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                button4.Enabled = true;
                indexRow = e.RowIndex;

                DataGridViewRow row = DataGridViewPOS.Rows[indexRow];

                txtProductName.Text = row.Cells[0].Value.ToString();
                txtBrand.Text = row.Cells[1].Value.ToString();
                textBox1.Text = row.Cells[2].Value.ToString();
                txtProductPrice.Text = row.Cells[3].Value.ToString();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
