﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Thesis_Project
{
    public partial class Main : Form
    {

         MySqlConnection MyConn = new MySqlConnection("server = localhost; user id = root; password = admin; DATABASE = POS_INVENTORY");


        public Main( string UserName, string UserType)
        {
            InitializeComponent();
            lblUserName.Text = UserName;
            lblUserType.Text = UserType;
          

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            try
            {
                DateTime dateTime = DateTime.Now;
                this.lblHour.Text = dateTime.ToString("hh:mm tt");
                this.lblDate.Text = dateTime.ToString("dddd, dd MMMM yyyy");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void picClose_Click(object sender, EventArgs e)
        {
            if (DialogResult.Yes == MessageBox.Show("Are you sure you want to logout?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Warning))
            {
                MyConn.Open();
                MySqlCommand MyCommandUser = new MySqlCommand();
                string sqlUser = "insert into POS_INVENTORY.ActivityLog(LogUserName, LogUserType,LogDate,LogTime,LogActivity) values('" + lblUserName.Text + "','" + lblUserType.Text + "', '" + lblDate.Text + "', '" + lblHour.Text + "','Logged Out')";
                MyCommandUser.Connection = MyConn;
                MyCommandUser.CommandText = sqlUser;

                MyCommandUser.ExecuteNonQuery();

                this.Close();
                Login n = new Login();
                n.Show();
                MyConn.Close();
            }

        }

        private void employeeMaintenanceToolStripMenuItem_Click(object sender, EventArgs e)
        {
          
         
            Employee_Maintenance s = new Employee_Maintenance(lblUserName.Text, lblUserType.Text);
            s.Show();
        }

        private void productMaintenanceToolStripMenuItem_Click(object sender, EventArgs e)
        {
           
        }

        private void pointOfSaleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Point_of_Sale ps = new Point_of_Sale(lblUserName.Text, lblUserType.Text);
            ps.Show();
        }

        private void inventoryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Inventory_Report c = new Inventory_Report(lblUserName.Text, lblUserType.Text);
            c.Show();
        }

        private void salesReportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Sales_Report s = new Sales_Report();
            s.Show();
        }

        private void supplierMaintenanceToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Supplier_Maintenance s = new Supplier_Maintenance(lblUserName.Text, lblUserType.Text);
            s.Show();
        }

        private void pointOfSaleToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Point_of_Sale pos = new Point_of_Sale(lblUserName.Text, lblUserType.Text);
            pos.Show();
        }

        private void inventoryToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Inventory_Report ir = new Inventory_Report(lblUserName.Text, lblUserType.Text);
            ir.Show();
        }

        private void activityLogToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Activity_Log al = new Activity_Log();
            al.Show();
        }

        private void categoryMaintenanceToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Category c = new Category(lblUserName.Text, lblUserType.Text);
            c.Show();
        }

        private void Main_Load(object sender, EventArgs e)
        {
          

        }

        private void inventoryToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
           
        }

        private void transferToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void stockTransferToolStripMenuItem_Click(object sender, EventArgs e)
        {
           
        }

        private void branchMaintenanceToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Branches b = new Branches(lblUserName.Text, lblUserType.Text);
            b.Show();
        }

        private void lblDate_Click(object sender, EventArgs e)
        {

        }

        private void lblHour_Click(object sender, EventArgs e)
        {

        }

        private void brandMaintenanceToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Brand bd = new Brand(lblUserName.Text, lblUserType.Text);
            bd.Show();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
