﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.Drawing.Printing;

namespace Thesis_Project
{
    public partial class Sales_Report : Form
    {
        PrintDocument docPrint;
        MySqlConnection MyConn = new MySqlConnection();
        public Sales_Report()
        {
            InitializeComponent();
            MyConn.ConnectionString = "server = localhost; user id = root; password = admin; DATABASE = POS_INVENTORY";

          DisplaySalesReport();
            DisplayAmount();
            DisplaySum();
            DisplayAvgSale();
            button1 = new Button();
            button1.Location = new Point(12, 12);
            button1.Text = "&Print Preview...";
            button1.Width = 100;
            button1.Click += new EventHandler(button1_Click);

            Controls.Add(button1);

            printPreviewDialog1 = new PrintPreviewDialog();
            docPrint = new PrintDocument();

            printPreviewDialog1.Document = docPrint;

        }

        DataTable dt = new DataTable();

        void DisplaySalesReport()
        {
            try
           {
               MyConn.Open();
               

                MySqlCommand MyCommand = new MySqlCommand();
                string sql = "select SalesNo as 'Sales ID', ProductName as 'Product',Brand as 'Brand',Quantity,Dates as 'Date',Times as 'Time',Amount from POS_INVENTORY.SalesReport";
                MyCommand.Connection = MyConn;
               MyCommand.CommandText = sql;

              MySqlDataAdapter da = new MySqlDataAdapter(MyCommand);

              dt.Clear();
                da.Fill(dt);
                DataGridSale.DataSource = dt;

              MyConn.Close();
            }
           catch (Exception ex)
          {
               MessageBox.Show(ex.Message);
           }
      }
        DataTable dt1 = new DataTable();
        void DisplaySalesReport1()
        {
            try
            {
               

                MyConn.Open();

                MySqlCommand MyCommaand = new MySqlCommand();
                string ssssql = "Select * from SalesReport GROUP BY ProductName ORDER BY Quantity ASC ";
                MyCommaand.Connection = MyConn;
                MyCommaand.CommandText = ssssql;

                MySqlDataAdapter daa = new MySqlDataAdapter(MyCommaand);

                dt1.Clear();
                daa.Fill(dt1);
                DataGridSale.DataSource = dt1;

                MyConn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        DataTable dt2 = new DataTable();
        void DisplaySalesReport2()
        {
            try
            {
                MyConn.Open();

                MySqlCommand MyCommaaand = new MySqlCommand();
                string sql = "SELECT * FROM SalesReport GROUP BY ProductName ORDER BY Quantity DESC";
                MyCommaaand.Connection = MyConn;
                MyCommaaand.CommandText = sql;

                MySqlDataAdapter daa = new MySqlDataAdapter(MyCommaaand);

                dt2.Clear();
                daa.Fill(dt2);
                DataGridSale.DataSource = dt2;

                MyConn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        DataTable dt5 = new DataTable();
        void DisplaySalesReport5()
        {
            try
            {
                MyConn.Open();

                MySqlCommand MyYCommaaaaand = new MySqlCommand();
                string Ssqqqql = "SELECT * FROM SalesReport GROUP BY ProductName ORDER BY Amount ASC";
                MyYCommaaaaand.Connection = MyConn;
                MyYCommaaaaand.CommandText = Ssqqqql;

                MySqlDataAdapter dDaa = new MySqlDataAdapter(MyYCommaaaaand);

                dt5.Clear();
                dDaa.Fill(dt5);
                DataGridSale.DataSource = dt5;

                MyConn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        DataTable dt6 = new DataTable();
        void DisplaySalesReport6()
        {
            try
            {
                MyConn.Open();

                MySqlCommand MMMyCommaaaaand = new MySqlCommand();
                string SSSsqqqql = "SELECT * FROM SalesReport GROUP BY ProductName ORDER BY Amount DESC";
                MMMyCommaaaaand.Connection = MyConn;
                MMMyCommaaaaand.CommandText = SSSsqqqql;

                MySqlDataAdapter DDDDdaa = new MySqlDataAdapter(MMMyCommaaaaand);

                dt6.Clear();
                DDDDdaa.Fill(dt6);
                DataGridSale.DataSource = dt6;

                MyConn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        void DisplayAvgSale()
        {
            lblTotalSales.Text = DataGridSale.Rows.Count.ToString();
        }

       void DisplaySum()
        {
            decimal sum = 0;
            for (int i = 0; i < DataGridSale.Rows.Count; ++i)
            {
                sum += Convert.ToDecimal(DataGridSale.Rows[i].Cells[3].Value);
            }
            lblTotalItems.Text = sum.ToString();
        }

        void DisplayAmount()
        {
            decimal sum = 0;
            for (int i = 0; i < DataGridSale.Rows.Count; ++i)
            {
                sum += Convert.ToDecimal(DataGridSale.Rows[i].Cells[6].Value);
            }
            lblTotalAmount.Text = sum.ToString();
        }


        private void picClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Sales_Report_Load(object sender, EventArgs e)
        {


        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
          DisplaySalesReport();
        }

        private void txtDate_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            try
            {
                DateTime dateTime = DateTime.Now;
                this.lblHour.Text = dateTime.ToString("hh:mm tt");
                this.lblDate.Text = dateTime.ToString("dddd, dd MMMM yyyy");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void DataGridSale_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {

        

            Bitmap bm = new Bitmap(DataGridSale.Width, DataGridSale.Height);
            DataGridSale.DrawToBitmap(bm, new Rectangle(25, 25, DataGridSale.Width, DataGridSale.Height));
            e.Graphics.DrawImage(bm, 0, 250);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            printPreviewDialog1.Document = printDocument1;
            printPreviewDialog1.ShowDialog();

        }

        private void printPreviewDialog1_Load(object sender, EventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            

        }

        private void button4_Click(object sender, EventArgs e)
        {
          
            dateTimePicker1.ResetText();
            dateTimePicker2.ResetText();
            DisplaySalesReport();
        }

        private void lblDate_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click_1(object sender, EventArgs e)
        {
           
        }

        private void button2_Click_2(object sender, EventArgs e)
        {
            try
            {
                MyConn.Open();

                MySqlCommand MyCommaand = new MySqlCommand();
                string ssssql = "Select SalesNo as 'Sales ID', ProductName as 'Product',Brand as 'Brand',Quantity,Dates as 'Date',Times as 'Time',Amount from SalesReport where Dates between  '" + dateTimePicker1.Value.ToString("dddd, dd MMMM yyyy") + "'  &&  Dates = '" + dateTimePicker2.Value.ToString("dddd, dd MMMM yyyy") + "' ORDER BY ProductName DESC ";
                MyCommaand.Connection = MyConn;
                MyCommaand.CommandText = ssssql;

                MySqlDataAdapter daa = new MySqlDataAdapter(MyCommaand);

                dt1.Clear();
                daa.Fill(dt1);
                DataGridSale.DataSource = dt1;

                MyConn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
