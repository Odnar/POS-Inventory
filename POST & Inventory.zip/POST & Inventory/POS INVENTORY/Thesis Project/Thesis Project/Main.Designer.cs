﻿namespace Thesis_Project
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Main));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.FileMaintenance = new System.Windows.Forms.ToolStripMenuItem();
            this.employeeMaintenanceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.categoryMaintenanceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.supplierMaintenanceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.branchMaintenanceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.brandMaintenanceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pointOfSaleToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.inventoryToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.ReportsModule = new System.Windows.Forms.ToolStripMenuItem();
            this.salesReportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.activityLogToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.label1 = new System.Windows.Forms.Label();
            this.lblUserName = new System.Windows.Forms.Label();
            this.lblUserType = new System.Windows.Forms.Label();
            this.picClose = new System.Windows.Forms.PictureBox();
            this.lblDate = new System.Windows.Forms.Label();
            this.lblHour = new System.Windows.Forms.Label();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picClose)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.AutoSize = false;
            this.menuStrip1.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.FileMaintenance,
            this.pointOfSaleToolStripMenuItem1,
            this.inventoryToolStripMenuItem1,
            this.ReportsModule});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1370, 35);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // FileMaintenance
            // 
            this.FileMaintenance.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.employeeMaintenanceToolStripMenuItem,
            this.categoryMaintenanceToolStripMenuItem,
            this.supplierMaintenanceToolStripMenuItem,
            this.branchMaintenanceToolStripMenuItem,
            this.brandMaintenanceToolStripMenuItem});
            this.FileMaintenance.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FileMaintenance.Name = "FileMaintenance";
            this.FileMaintenance.Size = new System.Drawing.Size(153, 31);
            this.FileMaintenance.Text = "File Maintenance";
            // 
            // employeeMaintenanceToolStripMenuItem
            // 
            this.employeeMaintenanceToolStripMenuItem.Name = "employeeMaintenanceToolStripMenuItem";
            this.employeeMaintenanceToolStripMenuItem.Size = new System.Drawing.Size(264, 26);
            this.employeeMaintenanceToolStripMenuItem.Text = "Employee maintenance ";
            this.employeeMaintenanceToolStripMenuItem.Click += new System.EventHandler(this.employeeMaintenanceToolStripMenuItem_Click);
            // 
            // categoryMaintenanceToolStripMenuItem
            // 
            this.categoryMaintenanceToolStripMenuItem.Name = "categoryMaintenanceToolStripMenuItem";
            this.categoryMaintenanceToolStripMenuItem.Size = new System.Drawing.Size(264, 26);
            this.categoryMaintenanceToolStripMenuItem.Text = "Category Maintenance";
            this.categoryMaintenanceToolStripMenuItem.Click += new System.EventHandler(this.categoryMaintenanceToolStripMenuItem_Click);
            // 
            // supplierMaintenanceToolStripMenuItem
            // 
            this.supplierMaintenanceToolStripMenuItem.Name = "supplierMaintenanceToolStripMenuItem";
            this.supplierMaintenanceToolStripMenuItem.Size = new System.Drawing.Size(264, 26);
            this.supplierMaintenanceToolStripMenuItem.Text = "Supplier Maintenance";
            this.supplierMaintenanceToolStripMenuItem.Click += new System.EventHandler(this.supplierMaintenanceToolStripMenuItem_Click);
            // 
            // branchMaintenanceToolStripMenuItem
            // 
            this.branchMaintenanceToolStripMenuItem.Name = "branchMaintenanceToolStripMenuItem";
            this.branchMaintenanceToolStripMenuItem.Size = new System.Drawing.Size(264, 26);
            this.branchMaintenanceToolStripMenuItem.Text = "Branch Maintenance";
            this.branchMaintenanceToolStripMenuItem.Click += new System.EventHandler(this.branchMaintenanceToolStripMenuItem_Click);
            // 
            // brandMaintenanceToolStripMenuItem
            // 
            this.brandMaintenanceToolStripMenuItem.Name = "brandMaintenanceToolStripMenuItem";
            this.brandMaintenanceToolStripMenuItem.Size = new System.Drawing.Size(264, 26);
            this.brandMaintenanceToolStripMenuItem.Text = "Brand Maintenance";
            this.brandMaintenanceToolStripMenuItem.Click += new System.EventHandler(this.brandMaintenanceToolStripMenuItem_Click);
            // 
            // pointOfSaleToolStripMenuItem1
            // 
            this.pointOfSaleToolStripMenuItem1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pointOfSaleToolStripMenuItem1.Name = "pointOfSaleToolStripMenuItem1";
            this.pointOfSaleToolStripMenuItem1.Size = new System.Drawing.Size(119, 31);
            this.pointOfSaleToolStripMenuItem1.Text = "Point of Sale";
            this.pointOfSaleToolStripMenuItem1.Click += new System.EventHandler(this.pointOfSaleToolStripMenuItem1_Click);
            // 
            // inventoryToolStripMenuItem1
            // 
            this.inventoryToolStripMenuItem1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.inventoryToolStripMenuItem1.Name = "inventoryToolStripMenuItem1";
            this.inventoryToolStripMenuItem1.Size = new System.Drawing.Size(96, 31);
            this.inventoryToolStripMenuItem1.Text = "Inventory";
            this.inventoryToolStripMenuItem1.Click += new System.EventHandler(this.inventoryToolStripMenuItem1_Click);
            // 
            // ReportsModule
            // 
            this.ReportsModule.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.salesReportToolStripMenuItem,
            this.activityLogToolStripMenuItem});
            this.ReportsModule.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ReportsModule.Name = "ReportsModule";
            this.ReportsModule.Size = new System.Drawing.Size(80, 31);
            this.ReportsModule.Text = "Reports";
            // 
            // salesReportToolStripMenuItem
            // 
            this.salesReportToolStripMenuItem.Name = "salesReportToolStripMenuItem";
            this.salesReportToolStripMenuItem.Size = new System.Drawing.Size(174, 26);
            this.salesReportToolStripMenuItem.Text = "Sales Report";
            this.salesReportToolStripMenuItem.Click += new System.EventHandler(this.salesReportToolStripMenuItem_Click);
            // 
            // activityLogToolStripMenuItem
            // 
            this.activityLogToolStripMenuItem.Name = "activityLogToolStripMenuItem";
            this.activityLogToolStripMenuItem.Size = new System.Drawing.Size(174, 26);
            this.activityLogToolStripMenuItem.Text = "Audit Trail";
            this.activityLogToolStripMenuItem.Click += new System.EventHandler(this.activityLogToolStripMenuItem_Click);
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Britannic Bold", 150F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(196, 284);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(1019, 221);
            this.label1.TabIndex = 8;
            this.label1.Text = "FEELMORE";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblUserName
            // 
            this.lblUserName.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lblUserName.Location = new System.Drawing.Point(12, 45);
            this.lblUserName.Name = "lblUserName";
            this.lblUserName.Size = new System.Drawing.Size(0, 0);
            this.lblUserName.TabIndex = 9;
            // 
            // lblUserType
            // 
            this.lblUserType.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lblUserType.Location = new System.Drawing.Point(12, 130);
            this.lblUserType.Name = "lblUserType";
            this.lblUserType.Size = new System.Drawing.Size(0, 0);
            this.lblUserType.TabIndex = 10;
            // 
            // picClose
            // 
            this.picClose.BackColor = System.Drawing.SystemColors.MenuBar;
            this.picClose.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picClose.BackgroundImage")));
            this.picClose.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picClose.Cursor = System.Windows.Forms.Cursors.Hand;
            this.picClose.Location = new System.Drawing.Point(1334, 0);
            this.picClose.Name = "picClose";
            this.picClose.Size = new System.Drawing.Size(36, 35);
            this.picClose.TabIndex = 5;
            this.picClose.TabStop = false;
            this.picClose.Click += new System.EventHandler(this.picClose_Click);
            // 
            // lblDate
            // 
            this.lblDate.BackColor = System.Drawing.SystemColors.Menu;
            this.lblDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDate.Location = new System.Drawing.Point(1050, 4);
            this.lblDate.Name = "lblDate";
            this.lblDate.Size = new System.Drawing.Size(182, 26);
            this.lblDate.TabIndex = 6;
            this.lblDate.Text = "dddd dd MMMM, yyyy";
            this.lblDate.Click += new System.EventHandler(this.lblDate_Click);
            // 
            // lblHour
            // 
            this.lblHour.BackColor = System.Drawing.SystemColors.MenuBar;
            this.lblHour.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHour.Location = new System.Drawing.Point(1238, 4);
            this.lblHour.Name = "lblHour";
            this.lblHour.Size = new System.Drawing.Size(67, 31);
            this.lblHour.TabIndex = 7;
            this.lblHour.Text = "00:00:00 tt";
            this.lblHour.Click += new System.EventHandler(this.lblHour_Click);
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1370, 780);
            this.Controls.Add(this.lblUserType);
            this.Controls.Add(this.lblUserName);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblHour);
            this.Controls.Add(this.lblDate);
            this.Controls.Add(this.picClose);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Main";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Main_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picClose)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem FileMaintenance;
        private System.Windows.Forms.ToolStripMenuItem ReportsModule;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.PictureBox picClose;
        private System.Windows.Forms.ToolStripMenuItem employeeMaintenanceToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem salesReportToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem supplierMaintenanceToolStripMenuItem;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ToolStripMenuItem pointOfSaleToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem inventoryToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem activityLogToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem categoryMaintenanceToolStripMenuItem;
        private System.Windows.Forms.Label lblUserName;
        private System.Windows.Forms.Label lblUserType;
        private System.Windows.Forms.ToolStripMenuItem branchMaintenanceToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem brandMaintenanceToolStripMenuItem;
        private System.Windows.Forms.Label lblDate;
        private System.Windows.Forms.Label lblHour;
    }
}