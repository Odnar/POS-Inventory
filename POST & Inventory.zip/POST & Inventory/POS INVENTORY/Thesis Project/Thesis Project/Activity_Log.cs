﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.Drawing.Printing;

namespace Thesis_Project
{
    public partial class Activity_Log : Form
    {
        PrintDocument docPrint;
        MySqlConnection MyConn = new MySqlConnection();
        public Activity_Log()
        {
            InitializeComponent();
            MyConn.ConnectionString = "server = localhost; user id = root; password = admin; DATABASE = POS_INVENTORY";
            Display_Activity();
            button1 = new Button();
            button1.Location = new Point(12, 12);
            button1.Text = "&Print Preview...";
            button1.Width = 100;
            button1.Click += new EventHandler(button1_Click);

            Controls.Add(button1);

            printPreviewDialog1 = new PrintPreviewDialog();
            docPrint = new PrintDocument();

            printPreviewDialog1.Document = docPrint;

            cmbSearch.Items.Add("UserName");
            cmbSearch.Items.Add("UserType");
            cmbSearch.Items.Add("Activity");
            cmbSearch.Items.Add("Date");
            cmbSearch.Items.Add("Time");

        }
        private DataTable dt = new DataTable();

        void Display_Activity()
        {
            try
            {
                MyConn.Open();

                MySqlCommand MyCommand = new MySqlCommand();
                string sql = "select LogID, LogUserName, LogUserType,LogDate, LogTime, LogActivity  from POS_INVENTORY.ActivityLog";
                MyCommand.Connection = MyConn;
                MyCommand.CommandText = sql;

                MySqlDataAdapter da = new MySqlDataAdapter(MyCommand);

                dt.Clear();

                da.Fill(dt);
                DataGridAct.DataSource = dt;

                MyConn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void picClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Activity_Log_Load(object sender, EventArgs e)
        {
            Display_Activity();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            try
            {

                if (cmbSearch.Text == "UserName")
                {
                    DataView dav = new DataView(dt);
                    dav.RowFilter = string.Format("LogUserNAme LIKE '%{0}%'", txtSearch.Text);
                    DataGridAct.DataSource = dav;
                }
                else if (cmbSearch.Text == "User Type")
                {
                    DataView dav = new DataView(dt);
                    dav.RowFilter = string.Format("LogUserType LIKE '%{0}%'", txtSearch.Text);
                    DataGridAct.DataSource = dav;
                }
                else if (cmbSearch.Text == "Activity")
                {
                    DataView dav = new DataView(dt);
                    dav.RowFilter = string.Format("LogActivity LIKE '%{0}%'", txtSearch.Text);
                    DataGridAct.DataSource = dav;
                }
                else if (cmbSearch.Text == "Date")
                {
                    DataView dav = new DataView(dt);
                    dav.RowFilter = string.Format("LogDate LIKE '%{0}%'", txtSearch.Text);
                    DataGridAct.DataSource = dav;
                }
                else if (cmbSearch.Text == "Time")
                {
                    DataView dav = new DataView(dt);
                    dav.RowFilter = string.Format("LogTime LIKE '%{0}%'", txtSearch.Text);
                    DataGridAct.DataSource = dav;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            try
            {
                DateTime dateTime = DateTime.Now;
                this.lblHour.Text = dateTime.ToString("hh:mm tt");
                this.lblDate.Text = dateTime.ToString("dddd, dd MMMM yyyy");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            try
            {

                Bitmap bm = new Bitmap(DataGridAct.Width, DataGridAct.Height);
                DataGridAct.DrawToBitmap(bm, new Rectangle(0, 0, DataGridAct.Width, DataGridAct.Height));
                e.Graphics.DrawImage(bm, 0, 250);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void printPreviewDialog1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                printPreviewDialog1.Document = printDocument1;
                printPreviewDialog1.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void txtSearch_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = e.KeyChar != (char)Keys.Back && !char.IsSeparator(e.KeyChar) && !char.IsLetter(e.KeyChar) && !char.IsDigit(e.KeyChar);
        }
    }
}
