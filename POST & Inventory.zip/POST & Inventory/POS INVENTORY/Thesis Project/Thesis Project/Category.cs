﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Thesis_Project
{
    public partial class Category : Form
    {
        MySqlConnection MyConn = new MySqlConnection();
        DataSet ds = new DataSet();
        public Category(string message1, string message2)
        {
            InitializeComponent();
            MyConn.ConnectionString = "server = localhost; user id = root; password = admin; DATABASE = POS_INVENTORY";
            Display_Category();
            lblUserName.Text = message1;
            lblUserType.Text = message2;
        }

        void Display_Category()
        {
            try
            {
                MyConn.Open();

                MySqlCommand MyCommand = new MySqlCommand();
                string sql = "select CategoryID as 'Category ID', Category from POS_INVENTORY.CategoryInfo";
                MyCommand.Connection = MyConn;
                MyCommand.CommandText = sql;

                MySqlDataAdapter da = new MySqlDataAdapter(MyCommand);
                DataTable dt = new DataTable();

                dt.Clear();

                da.Fill(dt);
                DataGridCat.DataSource = dt;

                MyConn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void picClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnAddCategory_Click(object sender, EventArgs e)
        {
          
            try
            {
                if (btnAddCategory.Text == "Add")
                {

                    btnUpdateCategory.Enabled = false;
                    btnDeleteCategory.Enabled = false;
                }
                if (txtCategory.Text == string.Empty)
                {
                    MessageBox.Show("Please enter a value to Category Name!");
                    return;
                }

             
                    MySqlCommand cmd = new MySqlCommand("select * from CategoryInfo where Category = '" + txtCategory.Text + "'", MyConn);
                    MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                    da.Fill(ds);
                    int i = ds.Tables[0].Rows.Count;
                    if (i > 0)
                    {
                        MessageBox.Show("Data Repeated!", "Important Note", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        ds.Clear();
                    }
                    else
                    {
                        MyConn.Open();

                        MySqlCommand MyCommanda = new MySqlCommand();
                        string sqla = "insert into CategoryInfo (Category) values('" + txtCategory.Text + "')";
                        MyCommanda.Connection = MyConn;
                        MyCommanda.CommandText = sqla;

                        MyCommanda.ExecuteNonQuery();

                        MessageBox.Show("Successfully Added!", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);

                        MySqlCommand MyCommandUser = new MySqlCommand();
                        string sqlUser = "insert into POS_INVENTORY.ActivityLog(LogUserName, LogUserType,LogDate,LogTime,LogActivity) values('" + lblUserName.Text + "','" + lblUserType.Text + "', '" + lblDate.Text + "', '" + lblHour.Text + "','Added A New Category')";
                        MyCommandUser.Connection = MyConn;
                        MyCommandUser.CommandText = sqlUser;

                        MyCommandUser.ExecuteNonQuery();

                        MyConn.Close();

                        Display_Category();

                        btnAddCategory.Enabled = true;
                        btnUpdateCategory.Enabled = false;
                        btnDeleteCategory.Enabled = false;
                        txtCategoryID.Text = "";
                        txtCategory.Text = "";
                   
                }
           
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnUpdateCategory_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtCategory.Text == "" && txtCategoryID.Text == "")
                {
                    MessageBox.Show("Please Select Category Info!", "", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else
                {
                    MySqlCommand cmd = new MySqlCommand("select * from CategoryInfo where Category = '" + txtCategory.Text + "' and CategoryID = '" + txtCategoryID.Text + "'", MyConn);
                    MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                    da.Fill(ds);
                    int i = ds.Tables[0].Rows.Count;
                    if (i > 0)
                    {
                        MessageBox.Show("Data Repeated!", "Important Note", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        ds.Clear();
                    }
                    else
                    {

                        MyConn.Open();

                        MySqlCommand MyCommand = new MySqlCommand();
                        string sql = "update POS_INVENTORY.CategoryInfo set Category='" + txtCategory.Text + "' where CategoryID = " + txtCategoryID.Text + "";
                        MyCommand.Connection = MyConn;
                        MyCommand.CommandText = sql;

                        MyCommand.ExecuteNonQuery();

                        MessageBox.Show("Successfully Updated!", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);

                        MySqlCommand MyCommandUser = new MySqlCommand();
                        string sqlUser = "insert into POS_INVENTORY.ActivityLog(LogUserName, LogUserType,LogDate,LogTime,LogActivity) values('" + lblUserName.Text + "','" + lblUserType.Text + "', '" + lblDate.Text + "', '" + lblHour.Text + "','Updated A Category')";
                        MyCommandUser.Connection = MyConn;
                        MyCommandUser.CommandText = sqlUser;

                        MyCommandUser.ExecuteNonQuery();

                        MyConn.Close();

                        Display_Category();
                        btnUpdateCategory.Enabled = false;
                        btnDeleteCategory.Enabled = false;
                        btnDeleteCategory.Enabled = true;
                        txtCategoryID.Text = "";
                        txtCategory.Text = "";
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnDeleteCategory_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtCategory.Text == "" && txtCategoryID.Text == "")
                {
                    MessageBox.Show("Please Select Category Info!", "", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }

                else if (DialogResult.Yes == MessageBox.Show("Are you sure you want to delete the record?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Warning))
                {

                    MyConn.Open();

                    MySqlCommand MyCommand = new MySqlCommand();
                    string sql = "Delete from POS_INVENTORY.CategoryInfo where CategoryID=" + txtCategoryID.Text + "";
                    MyCommand.Connection = MyConn;
                    MyCommand.CommandText = sql;

                    MyCommand.ExecuteNonQuery();

                    MessageBox.Show("Successfully Deleted!", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);

                    MySqlCommand MyCommandUser = new MySqlCommand();
                    string sqlUser = "insert into POS_INVENTORY.ActivityLog(LogUserName, LogUserType,LogDate,LogTime,LogActivity) values('" + lblUserName.Text + "','" + lblUserType.Text + "', '" + lblDate.Text + "', '" + lblHour.Text + "','Deleted A Category')";
                    MyCommandUser.Connection = MyConn;
                    MyCommandUser.CommandText = sqlUser;

                    MyCommandUser.ExecuteNonQuery();

                    MyConn.Close();

                    Display_Category();
                    btnAddCategory.Enabled = true;
                    btnUpdateCategory.Enabled = false;
                    btnDeleteCategory.Enabled = false;
                    txtCategoryID.Text = "";
                    txtCategory.Text = "";


                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void DataGridCat_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {

                if (btnAddCategory.Text == "Add")
                {
                    btnAddCategory.Enabled = false;
                    btnDeleteCategory.Enabled = true;
                    btnUpdateCategory.Enabled = true;
                    btnClearCategory.Enabled = true;
                    txtCategoryID.Enabled = true;
                    txtCategory.Enabled = true;
                }

                if (e.RowIndex >= 0)
                    {
                        DataGridViewRow row = DataGridCat.Rows[e.RowIndex];

                        txtCategoryID.Text = row.Cells["Category ID"].Value.ToString();
                        txtCategory.Text = row.Cells["Category"].Value.ToString();


                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }

}
        private void timer1_Tick(object sender, EventArgs e)
        {
            try
            {
                DateTime dateTime = DateTime.Now;
                this.lblHour.Text = dateTime.ToString("hh:mm tt");
                this.lblDate.Text = dateTime.ToString("dddd, dd MMMM yyyy");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Category_Load(object sender, EventArgs e)
        {
            btnUpdateCategory.Enabled = false;
            btnDeleteCategory.Enabled = false;

        }

        private void btnClearCategory_Click(object sender, EventArgs e)
        {
            btnAddCategory.Enabled = true;
            btnUpdateCategory.Enabled = false;
            btnDeleteCategory.Enabled = false;
            txtCategoryID.Enabled = true;
            txtCategory.Enabled = true;
            txtCategoryID.Text = "";
            txtCategory.Text = "";
        }

        private void txtCategory_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                btnAddCategory_Click(this, new EventArgs());
            }
        }

        private void txtCategory_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = e.KeyChar != (char)Keys.Back && !char.IsSeparator(e.KeyChar) && !char.IsLetter(e.KeyChar) && !char.IsDigit(e.KeyChar);
        }
    }
        }
    